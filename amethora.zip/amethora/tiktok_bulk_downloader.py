#!/usr/bin/env python3
"""
TikTok Bulk Downloader - Download anônimo de vídeos/perfis com saída em ZIP
Requerimentos: Python 3.8+, yt-dlp
"""

import os
import sys
import subprocess
import zipfile
import shutil
import argparse
import tempfile
from pathlib import Path

# ============================================================
# CONFIGURAÇÕES
# ============================================================
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36"
)

YT_DLP_OPTS = [
    "--no-check-certificate",
    "--no-warnings",
    "--ignore-errors",
    "--no-continue",
    "--no-overwrites",
    "--extractor-args", "tiktok:api_hostname=www.tiktok.com",
    "--user-agent", USER_AGENT,
    "--impersonate", "chrome-131",              # ESSENCIAL: evita bloqueios
    "--add-header", "Accept-Language:en-US,en;q=0.9",
    "--add-header", "Accept-Encoding:gzip, deflate, br",
    "--sleep-requests", "3",                    # Pausa entre requisições
    "--sleep-interval", "5",
    "--max-sleep-interval", "8",
    "--limit-rate", "5M",
]


# ============================================================
# FUNÇÕES PRINCIPAIS
# ============================================================

def verificar_dependencias():
    """Verifica se o yt-dlp está instalado."""
    try:
        subprocess.run(["yt-dlp", "--version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("[ERRO] yt-dlp não encontrado. Instale com: pip install yt-dlp")
        return False


def baixar_midia(url, output_dir):
    """
    Baixa vídeo ou perfil inteiro do TikTok usando yt-dlp.
    Retorna a lista de arquivos baixados.
    """
    if not verificar_dependencias():
        return []

    # Cria diretório de saída
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Define padrão de nomeação
    output_template = os.path.join(output_dir, "%(uploader)s_%(id)s_%(title)s.%(ext)s")

    # Monta comando yt-dlp
    cmd = [
        "yt-dlp",
        url,
        "-o", output_template,
        "--no-playlist" if "/video/" in url else "--yes-playlist",
        "--format", "b",                      # Melhor qualidade disponível
        "--restrict-filenames",
    ] + YT_DLP_OPTS

    print(f"[INFO] Baixando: {url}")
    print(f"[INFO] Destino: {output_dir}")
    print("[INFO] Comando:", " ".join(cmd))

    try:
        # Mostra o progresso do yt-dlp em tempo real
        resultado = subprocess.run(cmd, check=False)

        if resultado.returncode != 0:
            print(f"[AVISO] yt-dlp retornou código {resultado.returncode}")

        # Lista arquivos baixados
        arquivos = []
        for raiz, _, arquivos_nome in os.walk(output_dir):
            for nome in arquivos_nome:
                if nome.endswith((".mp4", ".webm", ".mov", ".jpg", ".jpeg", ".png")):
                    caminho = os.path.join(raiz, nome)
                    arquivos.append(caminho)

        if not arquivos:
            print("[AVISO] Nenhum arquivo de mídia encontrado.")
            print("[DICA] Pode ser necessário exportar cookies do navegador:")
            print("      yt-dlp --cookies-from-browser chrome <URL>")

        return arquivos

    except Exception as e:
        print(f"[ERRO] Falha no download: {e}")
        return []


def criar_zip(arquivos, nome_zip, manter_originais=False):
    """
    Cria um arquivo ZIP com todos os arquivos baixados.
    """
    if not arquivos:
        print("[ERRO] Nenhum arquivo para compactar.")
        return False

    print(f"[INFO] Compactando {len(arquivos)} arquivo(s) em: {nome_zip}")

    try:
        with zipfile.ZipFile(nome_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for arquivo in arquivos:
                if os.path.exists(arquivo):
                    # Mantém estrutura de pastas relativa
                    arcname = os.path.basename(arquivo)
                    zipf.write(arquivo, arcname)
                    print(f"  + {arcname}")

        print(f"[SUCESSO] ZIP criado: {nome_zip} ({(os.path.getsize(nome_zip) / 1024 / 1024):.2f} MB)")

        # Remove arquivos originais se solicitado
        if not manter_originais:
            for arquivo in arquivos:
                try:
                    os.remove(arquivo)
                except OSError:
                    pass
            # Remove diretório se vazio
            dir_atual = os.path.dirname(arquivos[0]) if arquivos else None
            if dir_atual and os.path.exists(dir_atual) and not os.listdir(dir_atual):
                os.rmdir(dir_atual)

        return True

    except Exception as e:
        print(f"[ERRO] Falha ao criar ZIP: {e}")
        return False


def obter_nome_zip(url):
    """Gera nome para o arquivo ZIP baseado na URL."""
    # Remove https:// e parâmetros
    nome = url.replace("https://", "").replace("http://", "")
    nome = nome.split("?")[0].replace("/", "_")
    if len(nome) > 50:
        nome = nome[:50]
    return f"tiktok_{nome}.zip"


# ============================================================
# PONTO DE ENTRADA
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Baixa vídeos ou perfis do TikTok de forma anônima e gera ZIP.",
        epilog="Exemplos:\n"
               "  python tiktok_bulk_downloader.py https://www.tiktok.com/@usuario\n"
               "  python tiktok_bulk_downloader.py https://www.tiktok.com/@usuario/video/123\n"
               "  python tiktok_bulk_downloader.py -u https://... -o ./videos -z meu_zip\n"
               "  python tiktok_bulk_downloader.py -u https://... --keep-files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument("url", nargs="?", help="URL do vídeo ou perfil do TikTok")
    parser.add_argument("-u", "--url", dest="url_alt", help="URL (alternativo)")
    parser.add_argument("-o", "--output", default="./downloads",
                        help="Pasta temporária para downloads (padrão: ./downloads)")
    parser.add_argument("-z", "--zip-name", help="Nome do arquivo ZIP (padrão: automático)")
    parser.add_argument("--keep-files", action="store_true",
                        help="Mantém os arquivos originais após compactar")
    parser.add_argument("--no-zip", action="store_true",
                        help="Não cria ZIP, apenas baixa os arquivos")

    args = parser.parse_args()

    url = args.url or args.url_alt
    if not url:
        parser.print_help()
        print("\n[ERRO] URL é obrigatória.")
        sys.exit(1)

    # Cria diretório temporário para downloads
    temp_dir = tempfile.mkdtemp(prefix="tiktok_dl_")
    print(f"[INFO] Pasta temporária: {temp_dir}")

    try:
        # 1. Download
        arquivos = baixar_midia(url, temp_dir)

        if not arquivos:
            print("[ERRO] Nenhum arquivo baixado.")
            sys.exit(1)

        print(f"\n[INFO] {len(arquivos)} arquivo(s) baixado(s):")
        for a in arquivos:
            print(f"  - {os.path.basename(a)}")

        # 2. Cria ZIP (a menos que --no-zip)
        if not args.no_zip:
            nome_zip = args.zip_name or obter_nome_zip(url)
            if criar_zip(arquivos, nome_zip, args.keep_files):
                print(f"\n[SUCESSO] Download concluído! ZIP disponível em: {nome_zip}")
            else:
                print("[ERRO] Falha ao criar ZIP.")
                sys.exit(1)
        else:
            # Move arquivos para pasta de saída
            pasta_final = args.output
            Path(pasta_final).mkdir(parents=True, exist_ok=True)
            for arquivo in arquivos:
                destino = os.path.join(pasta_final, os.path.basename(arquivo))
                shutil.move(arquivo, destino)
            print(f"\n[SUCESSO] Arquivos salvos em: {pasta_final}")

    finally:
        # Limpa pasta temporária (se não tiver --keep-files e não for --no-zip)
        if not args.keep_files and not args.no_zip:
            try:
                shutil.rmtree(temp_dir)
                print("[INFO] Pasta temporária removida.")
            except OSError:
                pass


if __name__ == "__main__":
    main()
