#!/usr/bin/env bash
# Amethora — extrai (se o zip estiver ao lado) e deixa pronto.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [[ -f ../amethora.zip ]]; then
  echo "[*] Extraindo ../amethora.zip …"
  unzip -o ../amethora.zip -d /tmp/amethora-unpack >/dev/null
  if [[ -d /tmp/amethora-unpack/amethora ]]; then
    cp -a /tmp/amethora-unpack/amethora/. "$ROOT/"
  fi
  rm -rf /tmp/amethora-unpack
fi

if command -v python3 >/dev/null && [[ "${1:-}" == "--venv" ]]; then
  python3 -m venv .venv
  # shellcheck disable=SC1091
  source .venv/bin/activate
  pip install -U pip
  pip install -r requirements.txt
  echo "[ok] venv pronto. Rode: source .venv/bin/activate && uvicorn webapp.app:app --host 0.0.0.0 --port \${PORT:-8080}"
  exit 0
fi

echo "[ok] Arquivos em $ROOT"
echo "    Docker:  docker build -t amethora . && docker run -p 8080:8080 amethora"
echo "    Local:   bash setup.sh --venv"
