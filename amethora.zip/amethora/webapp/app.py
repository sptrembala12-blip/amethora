#!/usr/bin/env python3
"""Amethora — preview de perfil, seleção e download completo."""

from __future__ import annotations

import hashlib
import html
import json
import os
import random
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Optional
from urllib.parse import quote, urlparse

from curl_cffi import requests as cffi_requests
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tiktok_bulk_downloader import USER_AGENT  # noqa: E402

STATIC = Path(__file__).resolve().parent / "static"
DATA = Path("/tmp/amethora")
IMG_CACHE = DATA / "img"
DATA.mkdir(parents=True, exist_ok=True)
IMG_CACHE.mkdir(parents=True, exist_ok=True)

MEDIA_EXT = {".mp4", ".webm", ".mov", ".m4a", ".mkv"}
TIKTOK_HOSTS = {
    "tiktok.com",
    "www.tiktok.com",
    "m.tiktok.com",
    "vm.tiktok.com",
    "vt.tiktok.com",
}
IMG_HOST_OK = (
    "tiktokcdn.com",
    "tiktokcdn-us.com",
    "tiktokcdn-eu.com",
    "muscdn.com",
    "byteoversea.com",
    "ibyteimg.com",
    "tiktok.com",
    "ttwstatic.com",
)
TIKTOK_URL_RE = re.compile(
    r"https?://(?:www\.|m\.|vm\.|vt\.)?tiktok\.com/[^\s)\]>\"']+",
    re.IGNORECASE,
)
HANDLE_RE = re.compile(r"^@?[\w.]{2,24}$")
UNI_RE = re.compile(
    r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">(.*?)</script>',
    re.DOTALL,
)

JOB_TTL = 6 * 3600
PREVIEW_TTL = 3 * 3600
MAX_EVENTS = 2000
MAX_RETRIES = 4
ACTIVE_JOB = {"queued", "running", "zipping", "waiting"}
STREAM_CACHE: dict[str, tuple[str, float]] = {}
TIKWM_LOCK = threading.Lock()
TIKWM_LAST = 0.0
TIKWM_GAP = 1.2
TIKWM_CACHE: dict[str, dict[str, Any]] = {}
PHOTO_EXT = {".jpg", ".jpeg", ".png", ".webp", ".heic"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_tiktok_url(url: str) -> bool:
    try:
        parsed = urlparse(url.strip())
    except Exception:
        return False
    return parsed.scheme in {"http", "https"} and (parsed.hostname or "").lower() in TIKTOK_HOSTS


def normalize_tiktok_url(raw: str) -> Optional[str]:
    text = (raw or "").replace("&amp;", "&").strip()
    if HANDLE_RE.match(text.lstrip("@")) or (text.startswith("@") and HANDLE_RE.match(text)):
        handle = text if text.startswith("@") else f"@{text}"
        return f"https://www.tiktok.com/{handle}"
    match = TIKTOK_URL_RE.search(text)
    if not match:
        return None
    url = match.group(0).rstrip(".,;\"'")
    if not is_tiktok_url(url):
        return None
    parsed = urlparse(url)
    if "/video/" not in (parsed.path or "") and "/photo/" not in (parsed.path or ""):
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
    return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"


def is_single_video(url: str) -> bool:
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    path = parsed.path or ""
    if host in {"vm.tiktok.com", "vt.tiktok.com"}:
        return True
    return "/video/" in path or "/photo/" in path


def human_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    for unit, div in (("KB", 1024), ("MB", 1024**2), ("GB", 1024**3)):
        if n < div * 1024 or unit == "GB":
            val = n / div
            return f"{val:.1f} {unit}"
    return f"{n} B"


def compact_num(n: Optional[int]) -> str:
    if n is None:
        return "—"
    n = int(n)
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f}B".replace(".0B", "B")
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M".replace(".0M", "M")
    if n >= 10_000:
        return f"{n / 1_000:.1f}K".replace(".0K", "K")
    if n >= 1000:
        return f"{n / 1000:.1f}K"
    return str(n)


def safe_name(name: str) -> str:
    name = Path(name).name
    if not name or name in {".", ".."} or "/" in name or "\\" in name:
        raise HTTPException(400, "nome inválido")
    return name


def ytdlp_base() -> list[str]:
    return [
        "yt-dlp",
        "--no-colors",
        "--no-warnings",
        "--no-check-certificate",
        "--socket-timeout",
        "30",
        "--retries",
        "3",
        "--fragment-retries",
        "5",
        "--user-agent",
        USER_AGENT,
        "--impersonate",
        "chrome-131",
        "--add-header",
        "Accept-Language:pt-BR,pt;q=0.9,en;q=0.8",
    ]


def fetch_profile(url: str) -> dict[str, Any]:
    profile: dict[str, Any] = {
        "url": url,
        "handle": "",
        "nickname": "",
        "bio": "",
        "verified": False,
        "private": False,
        "avatar": "",
        "followers": 0,
        "following": 0,
        "likes": 0,
        "videos": 0,
        "kind": "profile",
    }
    if is_single_video(url):
        profile["kind"] = "video"
        return profile
    try:
        resp = cffi_requests.get(
            url,
            impersonate="chrome131",
            timeout=30,
            headers={"Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8"},
        )
        resp.raise_for_status()
    except Exception as exc:
        profile["error"] = f"Não abriu o perfil: {exc}"
        return profile

    match = UNI_RE.search(resp.text)
    if not match:
        profile["error"] = "TikTok não devolveu os dados do perfil."
        return profile
    try:
        data = json.loads(match.group(1))
        scope = data.get("__DEFAULT_SCOPE__", data)
        info = (scope.get("webapp.user-detail") or {}).get("userInfo") or {}
        user = info.get("user") or {}
        stats = info.get("stats") or {}
        handle = user.get("uniqueId") or ""
        profile.update(
            {
                "handle": f"@{handle}" if handle else "",
                "nickname": user.get("nickname") or handle,
                "bio": user.get("signature") or "",
                "verified": bool(user.get("verified")),
                "private": bool(user.get("privateAccount")),
                "avatar": user.get("avatarLarger") or user.get("avatarMedium") or "",
                "followers": int(stats.get("followerCount") or 0),
                "following": int(stats.get("followingCount") or 0),
                "likes": int(stats.get("heartCount") or stats.get("heart") or 0),
                "videos": int(stats.get("videoCount") or 0),
                "secUid": user.get("secUid") or "",
                "user_id": str(user.get("id") or ""),
            }
        )
    except Exception as exc:
        profile["error"] = f"Falha ao ler o perfil: {exc}"
    return profile


def entry_from_ytdlp(raw: dict[str, Any]) -> dict[str, Any]:
    thumbs = raw.get("thumbnails") or []
    cover = ""
    for prefer in ("cover", "originCover", "dynamicCover"):
        hit = next((t.get("url") for t in thumbs if t.get("id") == prefer and t.get("url")), "")
        if hit:
            cover = hit
            break
    if not cover and thumbs:
        cover = thumbs[-1].get("url") or ""
    vid = str(raw.get("id") or "")
    uploader = raw.get("uploader") or raw.get("channel") or ""
    webpage = raw.get("webpage_url") or raw.get("url") or ""
    if vid and not webpage:
        handle = (raw.get("uploader_id") or uploader or "").lstrip("@")
        webpage = f"https://www.tiktok.com/@{handle}/video/{vid}" if handle else ""
    return {
        "id": vid,
        "title": raw.get("title") or raw.get("description") or vid,
        "url": webpage,
        "thumb": cover,
        "views": raw.get("view_count") or 0,
        "likes": raw.get("like_count") or 0,
        "duration": raw.get("duration") or 0,
        "timestamp": raw.get("timestamp") or 0,
        "uploader": uploader,
        "kind": "video",
        "images": [],
    }


@dataclass
class Preview:
    id: str
    url: str
    profile: dict[str, Any]
    videos: list[dict[str, Any]] = field(default_factory=list)
    status: str = "listing"
    message: str = "Lendo o perfil…"
    events: list[dict[str, Any]] = field(default_factory=list)
    created: float = field(default_factory=time.time)
    list_done: bool = False
    error: Optional[str] = None
    cancel: bool = False
    proc: Optional[subprocess.Popen] = None
    lock: threading.Lock = field(default_factory=threading.Lock)
    seen: set[str] = field(default_factory=set)

    def emit(self, event: dict[str, Any]) -> None:
        event = {"ts": utc_now(), **event}
        with self.lock:
            self.events.append(event)
            if len(self.events) > MAX_EVENTS:
                self.events = self.events[-MAX_EVENTS:]

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "id": self.id,
                "url": self.url,
                "profile": self.profile,
                "videos": list(self.videos),
                "count": len(self.videos),
                "status": self.status,
                "message": self.message,
                "list_done": self.list_done,
                "error": self.error,
            }


@dataclass
class Job:
    id: str
    url: str
    mode: str
    wanted: list[str]
    status: str = "queued"
    message: str = "Na fila"
    created: float = field(default_factory=time.time)
    events: list[dict[str, Any]] = field(default_factory=list)
    files: list[dict[str, Any]] = field(default_factory=list)
    done_ids: list[str] = field(default_factory=list)
    failed_ids: list[str] = field(default_factory=list)
    percent: float = 0.0
    item: int = 0
    total: int = 0
    current_name: str = ""
    artifact: Optional[str] = None
    artifact_name: str = ""
    artifact_size: int = 0
    pack: str = "zip"
    error: Optional[str] = None
    work_dir: str = ""
    cancel: bool = False
    proc: Optional[subprocess.Popen] = None
    lock: threading.Lock = field(default_factory=threading.Lock)
    preview_id: str = ""
    touched: float = field(default_factory=time.time)

    def emit(self, event: dict[str, Any]) -> None:
        event = {"ts": utc_now(), **event}
        with self.lock:
            self.events.append(event)
            if len(self.events) > MAX_EVENTS:
                self.events = self.events[-MAX_EVENTS:]

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "id": self.id,
                "url": self.url,
                "mode": self.mode,
                "status": self.status,
                "message": self.message,
                "percent": self.percent,
                "item": self.item,
                "total": self.total,
                "current_name": self.current_name,
                "files": list(self.files),
                "done_ids": list(self.done_ids),
                "failed_ids": list(self.failed_ids),
                "artifact_name": self.artifact_name,
                "artifact_size": self.artifact_size,
                "pack": self.pack,
                "error": self.error,
                "created": self.created,
                "size_h": human_size(self.artifact_size) if self.artifact_size else "",
                "preview_id": self.preview_id,
            }


PREVIEWS: dict[str, Preview] = {}
JOBS: dict[str, Job] = {}
LOCK = threading.Lock()


class PreviewBody(BaseModel):
    url: str = Field(..., min_length=2, max_length=500)


class CreateJobBody(BaseModel):
    url: str = Field("", max_length=500)
    preview_id: str = ""
    mode: str = Field("selected", pattern="^(all|selected)$")
    pack: str = Field("zip", pattern="^(zip|loose)$")
    ids: list[str] = Field(default_factory=list)


app = FastAPI(title="Amethora", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


@app.get("/")
def index() -> FileResponse:
    return FileResponse(
        STATIC / "index.html",
        headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"},
    )


@app.get("/privacy")
def privacy() -> FileResponse:
    return FileResponse(STATIC / "privacy.html")


@app.get("/terms")
def terms() -> FileResponse:
    return FileResponse(STATIC / "terms.html")


@app.get("/ads.txt")
def ads_txt() -> Response:
    return FileResponse(STATIC / "ads.txt", media_type="text/plain")


@app.get("/robots.txt")
def robots() -> Response:
    return Response("User-agent: *\nAllow: /\nSitemap: /sitemap.txt\n", media_type="text/plain")


@app.get("/api/health")
def health() -> dict[str, Any]:
    ytdlp = "ausente"
    try:
        out = subprocess.run(["yt-dlp", "--version"], capture_output=True, text=True, check=True)
        ytdlp = out.stdout.strip()
    except Exception:
        pass
    return {"ok": ytdlp != "ausente", "yt_dlp": ytdlp, "ffmpeg": bool(shutil.which("ffmpeg")), "name": "Amethora"}


@app.post("/api/preview")
def create_preview(body: PreviewBody) -> dict[str, Any]:
    url = normalize_tiktok_url(body.url)
    if not url:
        raise HTTPException(400, "Cole um @ ou uma URL do TikTok.")
    pid = uuid.uuid4().hex[:10]

    if is_single_video(url):
        try:
            video, sess = fetch_video_detail(url)
        except Exception as exc:
            raise HTTPException(400, "Não abriu este vídeo.") from exc
        profile = {
            "url": video["url"],
            "handle": f"@{video['uploader']}" if video.get("uploader") else "",
            "nickname": video.get("nickname") or video.get("uploader") or "",
            "bio": "",
            "avatar": video.get("avatar") or "",
            "followers": 0,
            "following": 0,
            "likes": video.get("likes") or 0,
            "videos": 1,
            "kind": "video",
        }
        preview = Preview(
            id=pid,
            url=video["url"] or url,
            profile=profile,
            status="ready",
            message="1",
            list_done=True,
        )
        preview.videos = [video]
        preview.seen.add(video["id"])
        _store_play(video["id"], sess, video.get("play_urls") or [])
        with LOCK:
            PREVIEWS[pid] = preview
        return preview.snapshot()

    profile = fetch_profile(url)
    if profile.get("private"):
        raise HTTPException(400, "Este perfil é privado.")
    preview = Preview(id=pid, url=url, profile=profile, message="Carregando vídeos…")
    with LOCK:
        PREVIEWS[pid] = preview
    threading.Thread(target=_list_videos, args=(preview,), daemon=True).start()
    return preview.snapshot()


@app.get("/api/preview/{preview_id}")
def get_preview(preview_id: str) -> dict[str, Any]:
    return _get_preview(preview_id).snapshot()


@app.get("/api/preview/{preview_id}/stream")
def stream_preview(preview_id: str) -> StreamingResponse:
    preview = _get_preview(preview_id)
    return _sse(preview)


def _touch(job: Job) -> None:
    job.touched = time.time()


def _abort_job(job: Job, reason: str = "Cancelado.") -> None:
    job.cancel = True
    _kill(job.proc)
    if job.status in ACTIVE_JOB:
        job.status = "cancelled"
        job.message = reason
        job.emit({"type": "status", "status": "cancelled", "message": reason})


def _reap_jobs() -> None:
    now = time.time()
    for job in list(JOBS.values()):
        if job.status not in ACTIVE_JOB:
            continue
        idle = now - (job.touched or job.created)
        age = now - job.created
        if job.status == "waiting" and age > 900:
            _abort_job(job, "Lista demorou demais.")
        elif job.status in {"running", "zipping"} and idle > 600:
            _abort_job(job, "Download parado.")
        elif age > 3 * 3600:
            _abort_job(job, "Tempo esgotado.")


@app.post("/api/jobs")
def create_job(body: CreateJobBody) -> dict[str, str]:
    preview: Optional[Preview] = PREVIEWS.get(body.preview_id) if body.preview_id else None
    url = normalize_tiktok_url(body.url) or (preview.url if preview else None)
    if not url:
        raise HTTPException(400, "Cole um @ ou uma URL do TikTok.")

    with LOCK:
        _reap_jobs()
        if preview:
            for job in JOBS.values():
                if job.preview_id == preview.id and job.status in ACTIVE_JOB:
                    return {"id": job.id}
        for job in list(JOBS.values()):
            if job.status in ACTIVE_JOB:
                _abort_job(job, "Substituído.")

    if body.mode == "all":
        if not preview:
            raise HTTPException(400, "Abra o perfil primeiro para baixar tudo.")
        wanted = [v["id"] for v in preview.videos if v.get("id")]
        if preview.list_done and not wanted:
            raise HTTPException(400, "Nenhum vídeo encontrado neste perfil.")
    else:
        wanted = [i.strip() for i in body.ids if i and i.strip()]
        if not wanted:
            raise HTTPException(400, "Selecione pelo menos um vídeo.")
        if preview:
            known = {v["id"] for v in preview.videos}
            wanted = [i for i in wanted if i in known] or wanted

    # sem duplicar, ordem do perfil
    seen: set[str] = set()
    ordered: list[str] = []
    for vid in wanted:
        if vid not in seen:
            seen.add(vid)
            ordered.append(vid)

    job_id = uuid.uuid4().hex[:10]
    work = DATA / job_id
    work.mkdir(parents=True, exist_ok=True)
    job = Job(
        id=job_id,
        url=url,
        mode=body.mode,
        wanted=ordered,
        work_dir=str(work),
        pack=body.pack,
        total=len(ordered),
        message=f"0/{len(ordered)}",
        preview_id=preview.id if preview else "",
    )
    with LOCK:
        JOBS[job_id] = job
    threading.Thread(target=_run_job, args=(job, preview), daemon=True).start()
    return {"id": job_id}


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    return _get_job(job_id).snapshot()


@app.get("/api/jobs/{job_id}/stream")
def stream_job(job_id: str) -> StreamingResponse:
    return _sse(_get_job(job_id))


@app.post("/api/jobs/{job_id}/cancel")
def cancel_job(job_id: str) -> dict[str, str]:
    job = _get_job(job_id)
    _abort_job(job, "Cancelado.")
    return {"ok": "1"}


@app.get("/api/jobs/{job_id}/download")
def download_job(job_id: str) -> FileResponse:
    job = _get_job(job_id)
    if job.status != "done" or not job.artifact or not Path(job.artifact).is_file():
        raise HTTPException(404, "Arquivo ainda não está pronto.")
    media = "application/zip" if job.artifact.endswith(".zip") else "application/octet-stream"
    return FileResponse(
        job.artifact,
        filename=job.artifact_name,
        media_type=media,
        content_disposition_type="attachment",
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )


@app.get("/api/img")
def proxy_img(u: str = Query(..., min_length=12)) -> Response:
    parsed = urlparse(u)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in {"http", "https"} or not any(
        host == h or host.endswith("." + h) for h in IMG_HOST_OK
    ):
        raise HTTPException(400, "host bloqueado")
    key = hashlib.sha256(u.encode()).hexdigest()[:24]
    cache = IMG_CACHE / f"{key}.img"
    meta = IMG_CACHE / f"{key}.type"
    if cache.is_file() and cache.stat().st_size > 0:
        ctype = meta.read_text() if meta.is_file() else "image/jpeg"
        return Response(cache.read_bytes(), media_type=ctype)
    try:
        resp = cffi_requests.get(u, impersonate="chrome131", timeout=25)
        resp.raise_for_status()
    except Exception as exc:
        raise HTTPException(502, f"imagem indisponível: {exc}") from exc
    ctype = resp.headers.get("content-type", "image/jpeg").split(";")[0]
    if not ctype.startswith("image/"):
        raise HTTPException(400, "não é imagem")
    cache.write_bytes(resp.content)
    meta.write_text(ctype)
    return Response(resp.content, media_type=ctype)



@app.get("/manifest.webmanifest")
def manifest() -> FileResponse:
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def sw() -> Response:
    return Response(
        "self.addEventListener('install',()=>self.skipWaiting());"
        "self.addEventListener('activate',e=>e.waitUntil("
        "caches.keys().then(k=>Promise.all(k.map(c=>caches.delete(c)))).then(()=>self.registration.unregister())"
        "));",
        media_type="application/javascript",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/api/jobs/{job_id}/file/{name}")
def download_one_file(job_id: str, name: str) -> FileResponse:
    job = _get_job(job_id)
    name = safe_name(name)
    persist = ROOT / "downloads" / job.id
    candidates = [
        Path(job.work_dir) / name,
        persist / name,
        persist / "videos" / name,
        persist / "fotos" / name,
    ]
    path = next((p for p in candidates if p.is_file()), None)
    if not path:
        raise HTTPException(404, "arquivo não encontrado")
    return FileResponse(path, filename=name, media_type="video/mp4", content_disposition_type="attachment")


@app.api_route("/api/play/{preview_id}/{video_id}", methods=["GET", "HEAD"])
def play_video(preview_id: str, video_id: str, request: Request):
    local = _find_local_video(video_id)
    if local:
        return FileResponse(local, media_type="video/mp4")
    rec = _ensure_play(preview_id, video_id)
    headers = {"Referer": "https://www.tiktok.com/", "Accept": "*/*"}
    rng = request.headers.get("range")
    if rng:
        headers["Range"] = rng
    upstream = rec["session"].get(rec["url"], headers=headers, timeout=60, stream=True)
    if upstream.status_code >= 400:
        raise HTTPException(502, "Player indisponível.")

    def chunks():
        try:
            for part in upstream.iter_content(64 * 1024):
                if part:
                    yield part
        finally:
            upstream.close()

    out = {
        "Content-Type": upstream.headers.get("content-type", "video/mp4"),
        "Accept-Ranges": "bytes",
        "Cache-Control": "private, max-age=60",
    }
    if upstream.headers.get("content-length"):
        out["Content-Length"] = upstream.headers["content-length"]
    if upstream.headers.get("content-range"):
        out["Content-Range"] = upstream.headers["content-range"]
    return StreamingResponse(chunks(), status_code=upstream.status_code, headers=out)



def _get_preview(pid: str) -> Preview:
    prev = PREVIEWS.get(pid)
    if not prev:
        raise HTTPException(404, "Preview expirado.")
    return prev


def _get_job(jid: str) -> Job:
    job = JOBS.get(jid)
    if not job:
        raise HTTPException(404, "Download não encontrado.")
    return job


def _kill(proc: Optional[subprocess.Popen]) -> None:
    if not proc or proc.poll() is not None:
        return
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass


def _sse(obj: Preview | Job) -> StreamingResponse:
    def gen() -> Iterator[str]:
        idx = 0
        last_ping = time.time()
        snap = obj.snapshot()
        yield f"data: {json.dumps({'type': 'hello', 'job': snap, 'preview': snap}, ensure_ascii=False)}\n\n"
        while True:
            with obj.lock:
                batch = obj.events[idx:]
                idx = len(obj.events)
                status = obj.status
            for ev in batch:
                yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
            done = {"done", "error", "cancelled", "ready"}
            if isinstance(obj, Preview):
                done = {"ready", "error", "cancelled"}
            if status in done:
                yield f"data: {json.dumps({'type': 'closed', 'status': status})}\n\n"
                break
            now = time.time()
            if now - last_ping > 12:
                yield ": ping\n\n"
                last_ping = now
            time.sleep(0.15)

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


def _creator_query(sec_uid: str, cursor: int, device_id: str) -> dict[str, str]:
    return {
        "aid": "1988",
        "app_language": "en",
        "app_name": "tiktok_web",
        "browser_language": "en-US",
        "browser_name": "Mozilla",
        "browser_online": "true",
        "browser_platform": "Win32",
        "browser_version": "5.0 (Windows)",
        "channel": "tiktok_web",
        "cookie_enabled": "true",
        "count": "15",
        "cursor": str(cursor),
        "device_id": device_id,
        "device_platform": "web_pc",
        "focus_state": "true",
        "from_page": "user",
        "history_len": "2",
        "is_fullscreen": "false",
        "is_page_visible": "true",
        "language": "en",
        "os": "windows",
        "priority_region": "",
        "referer": "",
        "region": "US",
        "screen_height": "1080",
        "screen_width": "1920",
        "secUid": sec_uid,
        "type": "1",
        "tz_name": "UTC",
        "verifyFp": "verify_" + "".join(random.choices("0123456789abcdef", k=7)),
        "webcast_language": "en",
    }


def _entry_from_web_item(item: dict[str, Any], handle: str) -> dict[str, Any]:
    vid = str(item.get("id") or "")
    video = item.get("video") or {}
    stats = item.get("stats") or {}
    author = item.get("author") or {}
    uploader = (author.get("uniqueId") or handle or "").lstrip("@")
    image_post = item.get("imagePost") or {}
    image_sets: list[list[str]] = []
    for im in image_post.get("images") or []:
        raw_urls = ((im.get("imageURL") or {}).get("urlList")) or []
        urls = [u for u in raw_urls if isinstance(u, str) and u.startswith("http")]
        if urls:
            image_sets.append(urls)
    images = [s[0] for s in image_sets]
    if images:
        cover = images[0]
        kind = "photo"
        page = f"https://www.tiktok.com/@{uploader}/photo/{vid}" if uploader else ""
    else:
        kind = "video"
        cover = video.get("originCover") or video.get("cover") or video.get("dynamicCover") or ""
        page = f"https://www.tiktok.com/@{uploader}/video/{vid}" if uploader else ""
    return {
        "id": vid,
        "title": item.get("desc") or vid,
        "url": page,
        "thumb": cover,
        "views": stats.get("playCount") or 0,
        "likes": stats.get("diggCount") or 0,
        "duration": video.get("duration") or 0,
        "timestamp": item.get("createTime") or 0,
        "uploader": uploader,
        "kind": kind,
        "images": images,
        "image_sets": image_sets,
    }


def _add_preview_video(preview: Preview, item: dict[str, Any]) -> bool:
    if not item.get("id") or item["id"] in preview.seen:
        return False
    preview.seen.add(item["id"])
    with preview.lock:
        preview.videos.append(item)
        count = len(preview.videos)
    expected = preview.profile.get("videos") or 0
    preview.message = f"{count}" + (f" de {expected}" if expected else "")
    preview.emit({"type": "video", "video": item, "count": count, "expected": expected})
    return True


def _list_via_creator(preview: Preview) -> int:
    sec = (preview.profile or {}).get("secUid") or ""
    handle = (preview.profile or {}).get("handle") or ""
    if not sec:
        return 0
    device_id = str(random.randint(7250000000000000000, 7325099899999994577))
    sess = cffi_requests.Session(impersonate="chrome131")
    sess.headers.update(
        {"Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8", "Referer": preview.url or "https://www.tiktok.com/"}
    )
    try:
        sess.get(preview.url, timeout=25)
    except Exception:
        pass
    cursor = int(time.time() * 1000)
    empty = 0
    pages = 0
    while pages < 90 and not preview.cancel:
        pages += 1
        data: dict[str, Any] = {}
        items: list[Any] = []
        for attempt in range(5):
            try:
                resp = sess.get(
                    "https://www.tiktok.com/api/creator/item_list/",
                    params=_creator_query(sec, cursor, device_id),
                    timeout=25,
                )
                data = resp.json()
            except Exception:
                time.sleep(0.45 * (attempt + 1))
                continue
            items = data.get("itemList") or []
            if items:
                break
            time.sleep(0.45 * (attempt + 1))
        added = 0
        for raw in items:
            if isinstance(raw, dict) and _add_preview_video(preview, _entry_from_web_item(raw, handle)):
                added += 1
        if not items:
            empty += 1
            if empty >= 3 or data.get("hasMorePrevious") is False:
                break
            cursor -= 3 * 86400 * 1000
            if cursor < 1472706000000:
                break
            continue
        empty = 0
        last_ct = items[-1].get("createTime") if isinstance(items[-1], dict) else None
        nxt = int(last_ct * 1000) if last_ct else 0
        if not nxt or nxt == cursor:
            cursor -= 3 * 86400 * 1000
        else:
            cursor = nxt
        if data.get("hasMorePrevious") is False:
            break
    return len(preview.videos)


def _list_videos(preview: Preview) -> None:
    preview.status = "listing"
    preview.emit({"type": "status", "status": "listing", "message": "Carregando o grid…", "profile": preview.profile})
    try:
        _list_via_creator(preview)
    except Exception as exc:
        preview.emit({"type": "log", "level": "error", "message": str(exc)[:300]})

    count = len(preview.videos)
    expected = int(preview.profile.get("videos") or 0)
    if count == 0 or (expected and count < expected * 0.8):
        preview.message = f"{count} de {expected} — completando a lista…"
        preview.emit({"type": "status", "status": "listing", "message": preview.message})
        _list_videos_pass(preview, lazy=True)
        if expected and len(preview.videos) < expected:
            _list_videos_pass(preview, lazy=False)

    if preview.cancel:
        preview.status = "cancelled"
        return

    count = len(preview.videos)
    preview.list_done = True
    if count == 0:
        preview.status = "error"
        preview.error = "Nenhum post público encontrado."
        preview.emit({"type": "status", "status": "error", "message": preview.error})
        return
    preview.status = "ready"
    preview.message = f"{count}"
    preview.emit({"type": "status", "status": "ready", "message": preview.message, "count": count})


def _list_videos_pass(preview: Preview, lazy: bool) -> None:
    cmd = ytdlp_base() + [
        preview.url,
        "--flat-playlist",
        "--dump-json",
        "--skip-download",
        "--ignore-errors",
        "--yes-playlist",
        "--sleep-requests",
        "0.25",
    ]
    if lazy:
        cmd.append("--lazy-playlist")
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
            start_new_session=True,
            env=env,
        )
        preview.proc = proc
        assert proc.stdout is not None
        for line in proc.stdout:
            if preview.cancel:
                _kill(proc)
                break
            raw = line.strip()
            if not (raw.startswith("{") and raw.endswith("}")):
                continue
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue
            item = entry_from_ytdlp(data)
            _add_preview_video(preview, item)
        proc.wait(timeout=20)
    except Exception:
        pass
    finally:
        preview.proc = None


def _video_url(job: Job, preview: Optional[Preview], vid: str) -> str:
    if preview:
        for item in preview.videos:
            if item.get("id") == vid and item.get("url"):
                return item["url"]
    parsed = urlparse(job.url)
    handle = (parsed.path or "").strip("/").split("/")[0]
    if handle.startswith("@"):
        return f"https://www.tiktok.com/{handle}/video/{vid}"
    return f"https://www.tiktok.com/video/{vid}"



def _zip_folder(path: Path, item: dict[str, Any]) -> str:
    if item.get("kind") == "photo" or item.get("images") or path.suffix.lower() in PHOTO_EXT:
        return "fotos"
    return "videos"


def _media_headers(url: str) -> dict[str, str]:
    host = (urlparse(url).hostname or "").lower()
    if "tokcdn.com" in host or "tikwm" in host:
        return {"Referer": "https://tikwm.com/", "Origin": "https://tikwm.com", "Accept": "*/*"}
    return {"Referer": "https://www.tiktok.com/", "Accept": "*/*"}


def _looks_like_mp4(path: Path) -> bool:
    try:
        head = path.read_bytes()[:12]
    except Exception:
        return False
    return len(head) >= 8 and head[4:8] == b"ftyp"


def _pull_mp4(sess: Any, url: str, dest: Path, job: Job) -> bool:
    try:
        resp = sess.get(url, headers=_media_headers(url), timeout=180, stream=True)
        if resp.status_code >= 400:
            return False
        with dest.open("wb") as fh:
            for chunk in resp.iter_content(256 * 1024):
                if job.cancel:
                    dest.unlink(missing_ok=True)
                    return False
                if chunk:
                    fh.write(chunk)
                    _touch(job)
        got = dest.stat().st_size if dest.is_file() else 0
        if got < 40_000 or not _looks_like_mp4(dest):
            dest.unlink(missing_ok=True)
            return False
        return True
    except Exception:
        dest.unlink(missing_ok=True)
        return False


def _download_via_cdn(job: Job, preview: Optional[Preview], vid: str) -> Optional[Path]:
    if not preview:
        return None
    dest = Path(job.work_dir) / f"{vid}.mp4"
    try:
        rec = _ensure_clean_play(preview.id, vid)
        sess = (rec or {}).get("session") or cffi_requests.Session(impersonate="chrome131")
        urls = [u for u in ((rec or {}).get("urls") or []) if isinstance(u, str) and u.startswith("http")]
        if rec and rec.get("url") and rec["url"] not in urls:
            urls.insert(0, rec["url"])
        for media in urls:
            if _is_watermark_url(media):
                continue
            if _pull_mp4(sess, media, dest, job):
                if rec:
                    rec["url"] = media
                return dest
        page = _page_for_video(preview, vid)
        if page and not any("hdplay" in u.lower() for u in urls):
            hd_urls, _, _ = _tikwm_hdplay(page, sess)
            for media in hd_urls:
                if _is_watermark_url(media):
                    continue
                if _pull_mp4(sess, media, dest, job):
                    return dest
    except Exception:
        dest.unlink(missing_ok=True)
        return None
    return None


def _download_one(job: Job, url: str, vid: str) -> Optional[Path]:
    out_tpl = str(Path(job.work_dir) / f"%(uploader)s_{vid}_%(title).80s.%(ext)s")
    cmd = ytdlp_base() + [
        url,
        "-o",
        out_tpl,
        "--restrict-filenames",
        "--no-playlist",
        "--no-continue",
        "--no-overwrites",
        "--newline",
        "-S",
        "res,br",
        "--format",
        "bv*+ba/b",
        "--limit-rate",
        "8M",
    ]
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    job.proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        start_new_session=True,
        env=env,
    )
    assert job.proc.stdout is not None
    for line in job.proc.stdout:
        if job.cancel:
            _kill(job.proc)
            break
        raw = line.rstrip()
        if not raw:
            continue
        if raw.startswith("[download]") and "%" in raw:
            m = re.search(r"(\d+(?:\.\d+)?)%", raw)
            if m:
                job.percent = float(m.group(1))
                job.emit({"type": "progress", "item": job.item, "total": job.total, "percent": job.percent, "id": vid})
        elif raw.startswith("ERROR") or "ERROR:" in raw:
            job.emit({"type": "log", "level": "error", "message": raw[:300]})
    rc = job.proc.wait(timeout=20)
    job.proc = None
    if job.cancel:
        return None
    found: list[Path] = []
    for path in Path(job.work_dir).iterdir():
        if path.is_file() and path.suffix.lower() in MEDIA_EXT and vid in path.name:
            if path.stat().st_size > 8_000:
                found.append(path)
    if found:
        return max(found, key=lambda p: p.stat().st_size)
    if rc != 0:
        return None
    return None


def _preview_item(preview: Optional[Preview], vid: str) -> dict[str, Any]:
    if not preview:
        return {}
    for item in preview.videos:
        if item.get("id") == vid:
            return item
    return {}


def _photo_candidates(urls: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    extras: list[str] = []
    for u in urls:
        if not isinstance(u, str) or not u.startswith("http") or u in seen:
            continue
        seen.add(u)
        out.append(u)
        alt = u.replace("tplv-photomode-image", "tplv-photomode-original")
        if alt != u and alt not in seen:
            extras.append(alt)
    return out + extras


def _pull_largest(sess: Any, urls: list[str], dest: Path) -> Optional[Path]:
    best: Optional[bytes] = None
    for url in _photo_candidates(urls):
        try:
            resp = sess.get(
                url,
                timeout=60,
                headers={"Referer": "https://www.tiktok.com/", "Accept": "image/*,*/*"},
            )
            if resp.status_code >= 400 or not resp.content:
                continue
            body = resp.content
            if len(body) < 8_000:
                continue
            if body[:3] != b"\xff\xd8\xff" and body[:8] != b"\x89PNG\r\n\x1a\n" and body[:4] != b"RIFF":
                continue
            if best is None or len(body) > len(best):
                best = body
        except Exception:
            continue
    if not best:
        return None
    dest.write_bytes(best)
    return dest


def _download_photo(job: Job, preview: Optional[Preview], vid: str) -> list[Path]:
    item = _preview_item(preview, vid)
    sets: list[list[str]] = []
    for group in item.get("image_sets") or []:
        if isinstance(group, list) and group:
            sets.append([u for u in group if isinstance(u, str)])
    if not sets:
        sets = [[u] for u in (item.get("images") or []) if isinstance(u, str)]
    page = item.get("url") or ""
    if page:
        rec = _tikwm_lookup(page)
        extra = rec.get("images") or []
        if extra and not sets:
            sets = [[u] for u in extra if isinstance(u, str)]
        elif extra:
            for i, u in enumerate(extra):
                if isinstance(u, str) and u.startswith("http"):
                    if i < len(sets):
                        sets[i].append(u)
                    else:
                        sets.append([u])
    if not sets:
        return []
    sess = cffi_requests.Session(impersonate="chrome131")
    saved: list[Path] = []
    for i, urls in enumerate(sets, 1):
        if job.cancel:
            return saved
        name = f"{vid}_{i:02d}.jpg" if len(sets) > 1 else f"{vid}.jpg"
        dest = Path(job.work_dir) / name
        got = _pull_largest(sess, urls, dest)
        if got:
            saved.append(got)
            _touch(job)
    return saved


def _process_one(job: Job, preview: Optional[Preview], vid: str) -> list[Path]:
    if job.cancel:
        return []
    item = _preview_item(preview, vid)
    if item.get("kind") == "photo" or item.get("images"):
        got = _download_photo(job, preview, vid)
        if got:
            return got
    try:
        for attempt in range(3):
            if job.cancel:
                return []
            path = _download_via_cdn(job, preview, vid)
            if path:
                return [path]
            time.sleep(0.7 * (attempt + 1))
    except Exception as exc:
        job.emit({"type": "log", "level": "error", "message": f"{vid}: {exc}"})
        return []
    return []


def _run_job(job: Job, preview: Optional[Preview]) -> None:
    zf: Optional[zipfile.ZipFile] = None
    try:
        if job.mode == "all" and preview and not preview.list_done:
            job.status = "waiting"
            job.message = "Esperando a lista do perfil…"
            job.emit({"type": "status", "status": "waiting", "message": job.message})
            deadline = time.time() + 900
            while not preview.list_done and not preview.cancel and not job.cancel and time.time() < deadline:
                time.sleep(0.35)
                _touch(job)
            wanted = [v["id"] for v in preview.videos if v.get("id")]
            seen: set[str] = set()
            ordered: list[str] = []
            for vid in wanted:
                if vid not in seen:
                    seen.add(vid)
                    ordered.append(vid)
            job.wanted = ordered
            job.total = len(ordered)
            if not ordered:
                raise RuntimeError("A listagem terminou sem posts.")

        persist = ROOT / "downloads" / job.id
        persist.mkdir(parents=True, exist_ok=True)
        handle = (urlparse(job.url).path or "").strip("/").split("/")[0] or "tiktok"
        if job.pack == "zip":
            zip_name = f"amethora_{handle.lstrip('@')}_{len(job.wanted)}v.zip"
            zip_path = persist / zip_name
            zf = zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_STORED)
            job.artifact = str(zip_path)
            job.artifact_name = zip_name

        job.status = "running"
        remaining = list(job.wanted)
        attempt = 0
        workers = 2 if len(remaining) > 1 else 1

        def take(paths: list[Path], vid: str) -> None:
            item = _preview_item(preview, vid)
            for path in paths:
                folder = _zip_folder(path, item)
                info = {
                    "id": vid,
                    "name": path.name,
                    "folder": folder,
                    "size": path.stat().st_size,
                    "size_h": human_size(path.stat().st_size),
                }
                with job.lock:
                    job.files.append(info)
                    if vid not in job.done_ids:
                        job.done_ids.append(vid)
                    done = len(job.done_ids)
                    total = len(job.wanted) or 1
                    job.item = done
                    job.message = f"{done}/{total}"
                    job.percent = 100.0 * done / total
                if zf is not None:
                    with job.lock:
                        zf.write(path, f"{folder}/{path.name}")
                    try:
                        path.unlink()
                    except Exception:
                        pass
                else:
                    try:
                        dest_dir = persist / folder
                        dest_dir.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(path, dest_dir / path.name)
                    except Exception:
                        pass
                job.emit({"type": "file", "kind": folder, **info, "item": job.item, "total": job.total})
            _touch(job)
            job.emit(
                {
                    "type": "status",
                    "status": "running",
                    "message": job.message,
                    "item": job.item,
                    "total": job.total,
                    "percent": job.percent,
                    "id": vid,
                }
            )

        while remaining and attempt < MAX_RETRIES and not job.cancel:
            attempt += 1
            still: list[str] = []
            job.message = f"{len(job.done_ids)}/{len(job.wanted)}"
            job.emit({"type": "status", "status": "running", "message": job.message, "item": len(job.done_ids), "total": job.total})
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futs = {}
                for i, vid in enumerate(remaining):
                    if job.cancel:
                        break
                    if i:
                        time.sleep(0.12)
                    futs[pool.submit(_process_one, job, preview, vid)] = vid
                for fut in as_completed(futs):
                    vid = futs[fut]
                    if job.cancel:
                        break
                    try:
                        paths = fut.result()
                    except Exception as exc:
                        paths = []
                        job.emit({"type": "log", "level": "error", "message": f"{vid}: {exc}"})
                    if paths:
                        take(paths, vid)
                    else:
                        still.append(vid)
            remaining = still
            if remaining and attempt < MAX_RETRIES and not job.cancel:
                job.message = f"Reenviando {len(remaining)}…"
                job.emit({"type": "status", "status": "running", "message": job.message})
                time.sleep(2 * attempt)

        if job.cancel:
            job.status = "cancelled"
            job.message = "Cancelado."
            job.emit({"type": "status", "status": "cancelled", "message": job.message})
            return

        job.failed_ids = remaining
        if not job.files:
            job.status = "error"
            job.error = "Nenhum arquivo baixou."
            job.message = job.error
            job.emit({"type": "status", "status": "error", "message": job.error, "failed_ids": remaining})
            return

        if zf is not None:
            job.status = "zipping"
            job.message = "ZIP…"
            job.emit({"type": "status", "status": "zipping", "message": job.message})
            zf.close()
            zf = None
            zip_path = Path(job.artifact or "")
            if zip_path.is_file() and remaining:
                final_name = f"amethora_{handle.lstrip('@')}_{len(job.done_ids)}v.zip"
                final_path = zip_path.with_name(final_name)
                if final_path != zip_path:
                    zip_path.rename(final_path)
                    zip_path = final_path
                job.artifact = str(zip_path)
                job.artifact_name = zip_path.name
            job.artifact_size = Path(job.artifact).stat().st_size if job.artifact else 0
        else:
            job.artifact = None
            job.artifact_name = ""
            job.artifact_size = sum(int(f.get("size") or 0) for f in job.files)

        job.status = "done"
        job.percent = 100.0
        job.message = f"{len(job.done_ids)}/{len(job.wanted)}"
        job.emit(
            {
                "type": "done",
                "files": len(job.done_ids),
                "file_count": len(job.files),
                "file_list": list(job.files),
                "artifact_name": job.artifact_name,
                "artifact_size": job.artifact_size,
                "size_h": human_size(job.artifact_size),
                "zip": job.pack == "zip",
                "pack": job.pack,
                "failed": len(job.failed_ids),
            }
        )
        job.emit({"type": "status", "status": "done", "message": job.message})
    except Exception as exc:
        if job.cancel:
            job.status = "cancelled"
            return
        job.status = "error"
        job.error = str(exc)
        job.message = str(exc)
        job.emit({"type": "status", "status": "error", "message": str(exc)})
    finally:
        if zf is not None:
            try:
                zf.close()
            except Exception:
                pass
        job.proc = None




PLAY_CACHE: dict[str, dict] = {}




def _tikwm_wait() -> None:
    global TIKWM_LAST
    with TIKWM_LOCK:
        now = time.time()
        wait = TIKWM_GAP - (now - TIKWM_LAST)
        if wait > 0:
            time.sleep(wait)
        TIKWM_LAST = time.time()


TIKWM_TASK_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin": "https://tikwm.com",
    "Referer": "https://tikwm.com/",
    "x-requested-with": "XMLHttpRequest",
}


def _norm_media_url(u: str) -> str:
    if u.startswith("//"):
        return "https:" + u
    return u


def _tikwm_detail_media(detail: dict[str, Any]) -> tuple[list[str], int, list[str]]:
    urls: list[str] = []
    for key in ("play_url", "download_url", "url", "play"):
        raw = detail.get(key)
        if isinstance(raw, str) and raw.startswith("http"):
            u = _norm_media_url(raw)
            if u not in urls:
                urls.append(u)
    size = int(detail.get("size") or 0)
    images: list[str] = []
    raw_imgs = detail.get("images") or []
    if isinstance(raw_imgs, list):
        images = [u for u in raw_imgs if isinstance(u, str) and u.startswith("http")]
    return urls, size, images


def _tikwm_original(page_url: str, sess: Any) -> tuple[list[str], int, list[str]]:
    """Arquivo original de upload (bitrate alto). Vazio se a fila falhar."""
    payload: dict[str, Any] = {}
    for attempt in range(4):
        _tikwm_wait()
        try:
            resp = sess.post(
                "https://tikwm.com/api/video/task/submit",
                data=f"web=1&url={quote(page_url)}",
                headers=TIKWM_TASK_HEADERS,
                timeout=30,
            )
            payload = resp.json()
        except Exception:
            payload = {}
        if payload.get("code") == 0 and isinstance(payload.get("data"), dict):
            break
        time.sleep(1.4 * (attempt + 1))
    if payload.get("code") != 0 or not isinstance(payload.get("data"), dict):
        return [], 0, []
    data = payload["data"]
    urls, size, images = _tikwm_detail_media(data.get("detail") if isinstance(data.get("detail"), dict) else {})
    if urls:
        return urls, size, images
    task_id = data.get("task_id")
    if not task_id:
        return [], 0, images
    for _ in range(30):
        time.sleep(1.0)
        try:
            poll = sess.get(
                "https://tikwm.com/api/video/task/result",
                params={"task_id": str(task_id)},
                headers=TIKWM_TASK_HEADERS,
                timeout=25,
            )
            body = poll.json()
        except Exception:
            continue
        info = body.get("data") if isinstance(body.get("data"), dict) else {}
        status = info.get("status")
        if status == 2:
            urls, size, images = _tikwm_detail_media(
                info.get("detail") if isinstance(info.get("detail"), dict) else {}
            )
            if not images:
                raw_imgs = info.get("images") or []
                if isinstance(raw_imgs, list):
                    images = [u for u in raw_imgs if isinstance(u, str) and u.startswith("http")]
            return urls, size, images
        if status == 3:
            break
    return [], 0, images


def _tikwm_hdplay(page_url: str, sess: Any) -> tuple[list[str], int, list[str]]:
    urls: list[str] = []
    hd_size = 0
    images: list[str] = []
    for attempt in range(4):
        _tikwm_wait()
        data = None
        try:
            resp = sess.get(
                "https://www.tikwm.com/api/",
                params={"url": page_url, "hd": "1"},
                timeout=30,
            )
            payload = resp.json()
            data = payload.get("data") if payload.get("code") == 0 else None
        except Exception:
            data = None
        if isinstance(data, dict):
            hd = data.get("hdplay")
            if isinstance(hd, str) and hd.startswith("http") and not _is_watermark_url(hd):
                urls = [hd]
            hd_size = int(data.get("hd_size") or 0)
            raw_imgs = data.get("images") or []
            if isinstance(raw_imgs, list):
                images = [u for u in raw_imgs if isinstance(u, str) and u.startswith("http")]
            if urls or images:
                break
        time.sleep(1.1 * (attempt + 1))
    return urls, hd_size, images


def _tikwm_lookup(page_url: str) -> dict[str, Any]:
    now = time.time()
    with TIKWM_LOCK:
        hit = TIKWM_CACHE.get(page_url)
        if hit and hit.get("exp", 0) > now:
            return hit
    sess = cffi_requests.Session(impersonate="chrome131")
    sess.headers.update({"Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8", "Referer": "https://www.tiktok.com/"})
    urls, hd_size, images = _tikwm_original(page_url, sess)
    if not urls:
        urls, hd_size, images = _tikwm_hdplay(page_url, sess)
    rec = {
        "urls": urls,
        "session": sess,
        "hd_size": hd_size,
        "images": images,
        "exp": time.time() + 180,
    }
    with TIKWM_LOCK:
        TIKWM_CACHE[page_url] = rec
    return rec


def fetch_clean_media(page_url: str) -> tuple[list[str], Any]:
    """Só hdplay (1080p quando existir). Nunca o play 540p."""
    rec = _tikwm_lookup(page_url)
    return list(rec.get("urls") or []), rec.get("session")


def _rank_media_urls(video: dict[str, Any]) -> list[str]:
    ranked: list[tuple[int, int, str]] = []
    for info in video.get("bitrateInfo") or []:
        pa = info.get("PlayAddr") or {}
        br = int(info.get("Bitrate") or 0)
        w = int(pa.get("Width") or 0)
        h = int(pa.get("Height") or 0)
        for u in pa.get("UrlList") or []:
            if isinstance(u, str) and u.startswith("http"):
                ranked.append((br, w * h, u))
    pa2 = video.get("PlayAddrStruct") or {}
    for u in pa2.get("UrlList") or []:
        if isinstance(u, str) and u.startswith("http"):
            ranked.append((int(video.get("bitrate") or 0), int(video.get("width") or 0) * int(video.get("height") or 0), u))
    play = video.get("playAddr")
    if isinstance(play, str) and play.startswith("http"):
        ranked.append((int(video.get("bitrate") or 0), 0, play))
    ranked.sort(key=lambda x: (x[0], x[1]), reverse=True)
    out: list[str] = []
    seen: set[str] = set()
    for _, _, u in ranked:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def fetch_video_detail(url: str) -> tuple[dict[str, Any], Any]:
    sess = cffi_requests.Session(impersonate="chrome131")
    sess.headers.update({"Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8"})
    resp = sess.get(url, timeout=30)
    resp.raise_for_status()
    match = UNI_RE.search(resp.text)
    if not match:
        raise RuntimeError("sem dados do vídeo")
    data = json.loads(match.group(1))
    detail = (data.get("__DEFAULT_SCOPE__") or {}).get("webapp.video-detail") or {}
    st = (detail.get("itemInfo") or {}).get("itemStruct") or {}
    if not st.get("id"):
        raise RuntimeError("vídeo indisponível")
    video = st.get("video") or {}
    author = st.get("author") or {}
    stats = st.get("stats") or {}
    play_urls = [u for u in _rank_media_urls(video) if not _is_watermark_url(u)]
    clean, clean_sess = fetch_clean_media(str(resp.url))
    if clean:
        play_urls = clean + [u for u in play_urls if u not in clean]
        sess = clean_sess
    item = {
        "id": str(st.get("id")),
        "title": st.get("desc") or "",
        "url": str(resp.url).split("?")[0],
        "thumb": video.get("originCover") or video.get("cover") or "",
        "views": stats.get("playCount") or 0,
        "likes": stats.get("diggCount") or 0,
        "duration": video.get("duration") or 0,
        "uploader": author.get("uniqueId") or "",
        "nickname": author.get("nickname") or "",
        "avatar": author.get("avatarLarger") or author.get("avatarMedium") or "",
        "play_urls": play_urls,
    }
    return item, sess


def _is_watermark_url(u: str) -> bool:
    s = (u or "").lower()
    return any(token in s for token in ("webapp-prime", "watermark", "wmplay", "/aweme/v1/"))


def _store_play(video_id: str, session: Any, urls: list[str], hd_size: int = 0) -> None:
    urls = [u for u in urls if isinstance(u, str) and u.startswith("http") and not _is_watermark_url(u)]
    if not urls:
        return
    PLAY_CACHE[video_id] = {
        "session": session,
        "url": urls[0],
        "urls": urls,
        "hd_size": int(hd_size or 0),
        "exp": time.time() + 240,
        "clean": True,
    }


def _page_for_video(preview: Preview, video_id: str) -> str:
    for item in preview.videos:
        if item.get("id") == video_id:
            return item.get("url") or ""
    return _video_url(Job(id="x", url=preview.url, mode="selected", wanted=[]), preview, video_id)


def _ensure_clean_play(preview_id: str, video_id: str) -> Optional[dict]:
    rec = PLAY_CACHE.get(video_id)
    if rec and rec.get("exp", 0) > time.time() and rec.get("clean") and rec.get("url"):
        urls = [u for u in (rec.get("urls") or [rec["url"]]) if not _is_watermark_url(u)]
        if urls:
            rec["urls"] = urls
            rec["url"] = urls[0]
            return rec
    preview = _get_preview(preview_id)
    page = _page_for_video(preview, video_id)
    looked = _tikwm_lookup(page)
    clean = [u for u in (looked.get("urls") or []) if not _is_watermark_url(u)]
    if not clean:
        return None
    _store_play(video_id, looked.get("session"), clean, int(looked.get("hd_size") or 0))
    return PLAY_CACHE.get(video_id)


def _ensure_play(preview_id: str, video_id: str) -> dict:
    rec = _ensure_clean_play(preview_id, video_id)
    if rec:
        return rec
    preview = _get_preview(preview_id)
    page = _page_for_video(preview, video_id)
    item, sess = fetch_video_detail(page)
    _store_play(video_id, sess, item.get("play_urls") or [])
    rec = PLAY_CACHE.get(video_id)
    if not rec:
        raise HTTPException(404, "Player indisponível.")
    return rec




def _find_local_video(vid: str) -> Optional[Path]:
    for job in list(JOBS.values()):
        folder = ROOT / "downloads" / job.id
        work = Path(job.work_dir)
        for base in (folder, work, folder / "videos", folder / "fotos", work / "videos", work / "fotos"):
            if not base.is_dir():
                continue
            for path in base.iterdir():
                if path.is_file() and path.suffix.lower() in MEDIA_EXT and vid in path.name:
                    return path
    return None


def _direct_media_url(preview_id: str, video_id: str) -> str:
    key = f"{preview_id}:{video_id}"
    hit = STREAM_CACHE.get(key)
    if hit and hit[1] > time.time():
        return hit[0]
    preview = _get_preview(preview_id)
    page = ""
    for item in preview.videos:
        if item.get("id") == video_id:
            page = item.get("url") or ""
            break
    if not page:
        page = _video_url(Job(id="x", url=preview.url, mode="selected", wanted=[]), preview, video_id)
    cmd = ytdlp_base() + ["-g", "-f", "b", "--no-playlist", page]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=50)
    lines = [ln.strip() for ln in out.stdout.splitlines() if ln.strip().startswith("http")]
    if not lines:
        raise HTTPException(404, "Player indisponível.")
    url = lines[-1]
    STREAM_CACHE[key] = (url, time.time() + 180)
    return url


def _janitor() -> None:
    while True:
        time.sleep(90)
        now = time.time()
        with LOCK:
            for pid, prev in list(PREVIEWS.items()):
                if now - prev.created > PREVIEW_TTL:
                    prev.cancel = True
                    _kill(prev.proc)
                    PREVIEWS.pop(pid, None)
            for jid, job in list(JOBS.items()):
                if now - job.created > JOB_TTL:
                    job.cancel = True
                    _kill(job.proc)
                    JOBS.pop(jid, None)
                    shutil.rmtree(job.work_dir, ignore_errors=True)


threading.Thread(target=_janitor, daemon=True).start()
