/* Amethora — cole seu ID do AdSense para ativar os anúncios */
window.AMETHORA = {
  adsenseClient: "", // ex: "ca-pub-1234567890123456"
  adsenseSlots: {
    top: "",    // data-ad-slot do banner superior
    feed: "",   // data-ad-slot in-feed (após o perfil)
    footer: ""  // data-ad-slot rodapé
  }
};
