(() => {
  const $ = (id) => document.getElementById(id);
  const q = $("q");
  const form = $("search");
  const stage = $("stage");
  const grid = $("grid");
  const sheet = $("sheet");
  const modal = $("modal");
  const go = $("go");

  const state = {
    previewId: null,
    videos: [],
    selected: new Set(),
    selecting: false,
    listDone: false,
    profile: null,
    source: null,
    jobId: null,
    jobSource: null,
  };

  document.querySelectorAll(".seg-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.documentElement.dataset.theme = btn.dataset.theme;
      document.querySelectorAll(".seg-btn").forEach((b) => b.classList.toggle("on", b === btn));
      localStorage.setItem("amethora-theme", btn.dataset.theme);
    });
  });
  const savedTheme = localStorage.getItem("amethora-theme");
  if (savedTheme) {
    document.documentElement.dataset.theme = savedTheme;
    document.querySelectorAll(".seg-btn").forEach((b) => b.classList.toggle("on", b.dataset.theme === savedTheme));
  }

  $("paste").addEventListener("click", async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (t) q.value = t.trim().replace(/^@/, "");
    } catch {
      q.focus();
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const value = q.value.trim();
    if (!value) return;
    await openPreview(value);
  });

  $("selectToggle").addEventListener("click", () => {
    state.selecting = !state.selecting;
    grid.classList.toggle("selecting", state.selecting);
    $("selectToggle").classList.toggle("on", state.selecting);
    $("selectToggle").textContent = state.selecting ? "Pronto" : "Selecionar";
    $("selectAll").hidden = !state.selecting;
    refreshSheet();
  });

  $("selectAll").addEventListener("click", () => {
    if (state.selected.size === state.videos.length) state.selected.clear();
    else state.videos.forEach((v) => state.selected.add(v.id));
    paintSelection();
    refreshSheet();
  });

  $("dlAll").addEventListener("click", () => startJob("all"));
  $("dlSel").addEventListener("click", () => startJob("selected"));
  $("cancelDl").addEventListener("click", async () => {
    if (!state.jobId) return;
    await fetch(`/api/jobs/${state.jobId}/cancel`, { method: "POST" });
  });
  $("modalClose").addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  function imgUrl(u) {
    if (!u) return "";
    return `/api/img?u=${encodeURIComponent(u)}`;
  }

  function compact(n) {
    n = Number(n || 0);
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(".0", "") + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(".0", "") + "M";
    if (n >= 1e4) return (n / 1e3).toFixed(1).replace(".0", "") + "K";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
    return String(n);
  }

  async function openPreview(value) {
    resetPreview();
    go.disabled = true;
    go.textContent = "Abrindo…";
    stage.hidden = false;
    sheet.hidden = false;
    $("sheetKicker").textContent = "carregando";
    $("sheetTitle").textContent = "Lendo o perfil";
    $("sheetSub").textContent = "Foto, números e o grid entram em seguida.";
    skeletonProfile();
    try {
      const res = await fetch("/api/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: value }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(fmtDetail(data) || "Não abriu o perfil.");
      state.previewId = data.id;
      applyProfile(data.profile || {});
      (data.videos || []).forEach(addVideo);
      listenPreview(data.id);
      refreshSheet();
    } catch (err) {
      $("sheetTitle").textContent = "Não rolou";
      $("sheetSub").textContent = err.message;
    } finally {
      go.disabled = false;
      go.textContent = "Abrir perfil";
    }
  }

  function skeletonProfile() {
    ["nick", "handle", "bio", "stFollowing", "stFollowers", "stLikes", "stPosts"].forEach((id) => {
      $(id).classList.add("sk");
    });
  }

  function applyProfile(p) {
    state.profile = p;
    ["nick", "handle", "bio", "stFollowing", "stFollowers", "stLikes", "stPosts"].forEach((id) => {
      $(id).classList.remove("sk");
    });
    $("nick").textContent = p.nickname || p.handle || "—";
    $("handle").textContent = p.handle || "";
    $("bio").textContent = p.bio || "";
    $("stFollowing").textContent = compact(p.following);
    $("stFollowers").textContent = compact(p.followers);
    $("stLikes").textContent = compact(p.likes);
    $("stPosts").textContent = p.videos || 0;
    if (p.avatar) {
      $("avatar").src = imgUrl(p.avatar);
    }
    $("listState").textContent = "carregando grid";
  }

  function listenPreview(id) {
    if (state.source) state.source.close();
    state.source = new EventSource(`/api/preview/${id}/stream`);
    state.source.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "hello" && msg.preview) {
        applyProfile(msg.preview.profile || {});
        (msg.preview.videos || []).forEach(addVideo);
        if (msg.preview.list_done) markReady(msg.preview.count);
      }
      if (msg.type === "video" && msg.video) addVideo(msg.video);
      if (msg.type === "status" && msg.status === "ready") markReady(msg.count);
      if (msg.type === "status" && msg.status === "error") {
        $("listState").textContent = msg.message || "falhou";
      }
    };
  }

  function addVideo(v) {
    if (!v || !v.id || state.videos.some((x) => x.id === v.id)) return;
    state.videos.push(v);
    $("stPosts").textContent = state.profile?.videos || state.videos.length;
    $("listState").textContent = `${state.videos.length}` + (state.profile?.videos ? ` de ${state.profile.videos}` : "");
    const i = state.videos.length;
    const cell = document.createElement("article");
    cell.className = "cell";
    cell.dataset.id = v.id;
    cell.style.animationDelay = `${Math.min(i, 24) * 18}ms`;
    const src = v.thumb ? imgUrl(v.thumb) : "";
    cell.innerHTML = `
      ${src ? `<img alt="" loading="lazy" src="${src}" />` : ""}
      <span class="check"></span>
      <span class="play">▶</span>
      <span class="meta">▶ ${compact(v.views || 0)}</span>`;
    cell.addEventListener("click", () => onCell(v, cell));
    grid.appendChild(cell);
    refreshSheet();
  }

  function onCell(v, cell) {
    if (state.selecting) {
      if (state.selected.has(v.id)) state.selected.delete(v.id);
      else state.selected.add(v.id);
      cell.classList.toggle("on", state.selected.has(v.id));
      refreshSheet();
      return;
    }
    openModal(v);
  }

  function paintSelection() {
    grid.querySelectorAll(".cell").forEach((c) => {
      c.classList.toggle("on", state.selected.has(c.dataset.id));
    });
    $("selectAll").textContent = state.selected.size === state.videos.length ? "Limpar" : "Marcar visíveis";
  }

  function markReady(count) {
    state.listDone = true;
    $("listState").textContent = `${count || state.videos.length} no grid`;
    refreshSheet();
  }

  function refreshSheet() {
    const n = state.videos.length;
    const exp = state.profile?.videos || n;
    const sel = state.selected.size;
    $("selCount").textContent = sel ? `${sel} marcados` : "";
    $("dlSel").hidden = !(state.selecting && sel);
    $("dlSel").textContent = `Baixar selecionados (${sel})`;
    $("dlAll").textContent = state.listDone ? `Baixar tudo (${n})` : `Baixar tudo (${n}${exp > n ? "…" : ""})`;
    $("dlAll").disabled = n === 0;
    if (!state.jobId) {
      $("sheetKicker").textContent = state.listDone ? "perfil aberto" : "lendo o grid";
      $("sheetTitle").textContent = state.profile?.nickname || "Perfil";
      $("sheetSub").textContent = state.listDone
        ? `${n} vídeos. Tudo, ou só o que você marcar.`
        : `Já vieram ${n}${exp ? ` de ${exp}` : ""}. O botão de tudo espera a lista fechar.`;
    }
  }

  async function startJob(mode) {
    if (!state.previewId) return;
    if (mode === "all" && !state.listDone) {
      $("sheetSub").textContent = "Esperando o grid fechar para não faltar nenhum…";
    }
    if (mode === "selected" && state.selected.size === 0) return;
    $("dlAll").disabled = true;
    $("dlSel").disabled = true;
    $("meter").hidden = false;
    $("cancelDl").hidden = false;
    $("dlFile").hidden = true;
    try {
      const res = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          preview_id: state.previewId,
          mode,
          ids: mode === "selected" ? [...state.selected] : [],
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(fmtDetail(data) || "Não iniciou o download.");
      state.jobId = data.id;
      listenJob(data.id);
    } catch (err) {
      $("meterTxt").textContent = err.message;
      $("dlAll").disabled = false;
      $("dlSel").disabled = false;
    }
  }

  function listenJob(id) {
    if (state.jobSource) state.jobSource.close();
    state.jobSource = new EventSource(`/api/jobs/${id}/stream`);
    state.jobSource.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "hello" && msg.job) applyJob(msg.job);
      if (msg.type === "status") applyJob(msg);
      if (msg.type === "progress") {
        const pct = Number(msg.percent || 0);
        const overall = msg.total ? ((msg.item - 1 + pct / 100) / msg.total) * 100 : pct;
        $("meterBar").style.width = `${Math.max(2, overall)}%`;
        $("meterTxt").textContent = `${msg.item || 0}/${msg.total || 0} · ${Math.round(pct)}%`;
      }
      if (msg.type === "file") {
        $("meterTxt").textContent = `chegou ${msg.name || msg.id}`;
      }
      if (msg.type === "done") {
        $("meterBar").style.width = "100%";
        $("sheetKicker").textContent = "remessa pronta";
        $("sheetTitle").textContent = "Nada ficou de fora.";
        $("sheetSub").textContent = `${msg.files} vídeos · ${msg.size_h || ""}`;
        $("dlFile").hidden = false;
        $("dlFile").href = `/api/jobs/${id}/download`;
        $("dlFile").setAttribute("download", msg.artifact_name || "amethora.zip");
        $("cancelDl").hidden = true;
        $("dlAll").disabled = false;
        $("dlSel").disabled = false;
      }
      if (msg.type === "status" && msg.status === "error") {
        $("sheetTitle").textContent = "Faltou vídeo";
        $("sheetSub").textContent = msg.message || "Erro no lote.";
        $("dlAll").disabled = false;
        $("dlSel").disabled = false;
        $("cancelDl").hidden = true;
      }
    };
  }

  function applyJob(j) {
    if (j.message) $("meterTxt").textContent = j.message;
    if (j.total) {
      const pct = j.total ? (100 * (j.item || 0)) / j.total : 0;
      $("meterBar").style.width = `${pct}%`;
    }
    if (j.status === "done" && j.artifact_name && state.jobId) {
      $("dlFile").hidden = false;
      $("dlFile").href = `/api/jobs/${state.jobId}/download`;
    }
  }

  function openModal(v) {
    modal.hidden = false;
    $("modalFrame").innerHTML = `<iframe allowfullscreen allow="encrypted-media" src="https://www.tiktok.com/embed/v2/${v.id}"></iframe>`;
  }
  function closeModal() {
    modal.hidden = true;
    $("modalFrame").innerHTML = "";
  }

  function resetPreview() {
    if (state.source) state.source.close();
    if (state.jobSource) state.jobSource.close();
    state.previewId = null;
    state.videos = [];
    state.selected.clear();
    state.selecting = false;
    state.listDone = false;
    state.jobId = null;
    grid.innerHTML = "";
    grid.classList.remove("selecting");
    $("selectToggle").classList.remove("on");
    $("dlFile").hidden = true;
    $("meter").hidden = true;
    $("cancelDl").hidden = true;
    $("meterBar").style.width = "0";
    $("meterTxt").textContent = "";
  }

  function fmtDetail(data) {
    if (!data) return "";
    if (typeof data.detail === "string") return data.detail;
    if (Array.isArray(data.detail)) return data.detail.map((d) => d.msg || d).join(" ");
    return "";
  }

  /* AdSense — só carrega com ID + consentimento */
  const consent = $("consent");
  const cfg = window.AMETHORA || {};
  if (cfg.adsenseClient && !localStorage.getItem("amethora-consent")) {
    consent.hidden = false;
  }
  $("consentOk").addEventListener("click", () => {
    localStorage.setItem("amethora-consent", "1");
    consent.hidden = true;
    loadAds();
  });
  $("consentNo").addEventListener("click", () => {
    localStorage.setItem("amethora-consent", "0");
    consent.hidden = true;
  });
  if (cfg.adsenseClient && localStorage.getItem("amethora-consent") === "1") loadAds();

  function loadAds() {
    if (!cfg.adsenseClient) return;
    if (!document.querySelector('script[data-amethora-ads]')) {
      const s = document.createElement("script");
      s.async = true;
      s.crossOrigin = "anonymous";
      s.dataset.amethoraAds = "1";
      s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${cfg.adsenseClient}`;
      document.head.appendChild(s);
    }
    document.querySelectorAll(".ad-slot").forEach((el) => {
      const place = el.dataset.place;
      const slot = (cfg.adsenseSlots || {})[place];
      if (!slot) {
        el.hidden = false;
        el.textContent = "espaço AdSense";
        return;
      }
      el.hidden = false;
      el.innerHTML = `<ins class="adsbygoogle" style="display:block" data-ad-client="${cfg.adsenseClient}" data-ad-slot="${slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>`;
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch {}
    });
  }
})();
