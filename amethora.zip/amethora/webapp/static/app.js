(() => {
  const $ = (id) => document.getElementById(id);
  const q = $("q");
  const form = $("search");
  const stage = $("stage");
  const grid = $("grid");
  const sheet = $("sheet");
  const go = $("go");
  const player = $("player");
  const vidEl = $("playerVid");

  const state = {
    previewId: null,
    videos: [],
    selected: new Set(),
    selecting: false,
    listDone: false,
    profile: null,
    source: null,
    jobId: null,
    jobSource: null,
    pack: "zip",
    playIndex: 0,
    kind: "profile",
    progress: 0,
    finished: false,
    saving: false,
  };

  document.querySelectorAll(".seg-btn[data-theme]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.documentElement.dataset.theme = btn.dataset.theme;
      document.querySelectorAll(".seg-btn[data-theme]").forEach((b) => b.classList.toggle("on", b === btn));
      localStorage.setItem("amethora-theme", btn.dataset.theme);
    });
  });
  const savedTheme = localStorage.getItem("amethora-theme");
  if (savedTheme) {
    document.documentElement.dataset.theme = savedTheme;
    document.querySelectorAll(".seg-btn[data-theme]").forEach((b) => b.classList.toggle("on", b.dataset.theme === savedTheme));
  }

  document.querySelectorAll("#packSeg .seg-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.pack = btn.dataset.pack;
      document.querySelectorAll("#packSeg .seg-btn").forEach((b) => b.classList.toggle("on", b === btn));
    });
  });

  $("paste").addEventListener("click", async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (t) q.value = t.trim().replace(/^@/, "");
    } catch {
      q.focus();
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const value = q.value.trim();
    if (!value) return;
    await openPreview(value);
  });

  $("selectToggle").addEventListener("click", () => {
    state.selecting = !state.selecting;
    grid.classList.toggle("selecting", state.selecting);
    $("selectToggle").classList.toggle("on", state.selecting);
    $("selectToggle").textContent = state.selecting ? "Pronto" : "Selecionar";
    $("selectAll").hidden = !state.selecting;
    refreshSheet();
  });

  $("selectAll").addEventListener("click", () => {
    if (state.selected.size === state.videos.length) state.selected.clear();
    else state.videos.forEach((v) => state.selected.add(v.id));
    paintSelection();
    refreshSheet();
  });

  $("dlAll").addEventListener("click", () => startJob("all"));
  $("dlOne").addEventListener("click", () => startJob("all"));
  $("dlSel").addEventListener("click", () => startJob("selected"));
  $("singleOpen").addEventListener("click", () => openPlayer(0));
  $("dlFileOne").addEventListener("click", (e) => {
    e.preventDefault();
    saveRemote($("dlFileOne").href, $("dlFileOne").getAttribute("download") || "amethora.mp4");
  });
  $("dlFile").addEventListener("click", (e) => {
    e.preventDefault();
    saveRemote($("dlFile").href, $("dlFile").getAttribute("download") || "amethora.zip");
  });
  $("cancelDl").addEventListener("click", async () => {
    if (!state.jobId) return;
    const id = state.jobId;
    await fetch(`/api/jobs/${id}/cancel`, { method: "POST" }).catch(() => {});
    if (state.jobSource) { state.jobSource.close(); state.jobSource = null; }
    state.jobId = null;
    state.finished = false;
    state.saving = false;
    state.progress = 0;
    ["dlBox", "sheetBox"].forEach((i) => { const el = $(i); if (el) el.classList.remove("on"); });
    ["dlDone", "sheetDone"].forEach((i) => { const el = $(i); if (el) el.classList.remove("on"); });
    $("cancelDl").hidden = true;
    $("dlAll").disabled = false;
    $("dlSel").disabled = false;
    $("dlOne").disabled = false;
    $("meterTxt").textContent = "";
    refreshSheet();
  });

  $("playerClose").addEventListener("click", closePlayer);
  $("playerPlay").addEventListener("click", togglePlay);
  $("playerMute").addEventListener("click", () => {
    vidEl.muted = !vidEl.muted;
    $("playerMute").textContent = vidEl.muted ? "×" : "♪";
  });
  $("playerPrev").addEventListener("click", () => stepPlay(-1));
  $("playerNext").addEventListener("click", () => stepPlay(1));
  $("playerBar").addEventListener("click", (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const p = (e.clientX - r.left) / r.width;
    if (vidEl.duration) vidEl.currentTime = p * vidEl.duration;
  });
  vidEl.addEventListener("timeupdate", syncBar);
  vidEl.addEventListener("ended", () => { $("playerPlay").textContent = "▶"; });
  vidEl.addEventListener("play", () => { $("playerPlay").textContent = "❚❚"; });
  vidEl.addEventListener("pause", () => { $("playerPlay").textContent = "▶"; });

  function imgUrl(u) {
    if (!u) return "";
    return `/api/img?u=${encodeURIComponent(u)}`;
  }

  function compact(n) {
    n = Number(n || 0);
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(".0", "") + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(".0", "") + "M";
    if (n >= 1e4) return (n / 1e3).toFixed(1).replace(".0", "") + "K";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
    return String(n);
  }

  function fmtTime(s) {
    s = Math.max(0, Math.floor(s || 0));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }

  function showDone() {
    state.finished = true;
    state.saving = false;
    ["dlBox", "sheetBox"].forEach((id) => { const el = $(id); if (el) el.classList.remove("on"); });
    ["dlDone", "sheetDone"].forEach((id) => { const el = $(id); if (el) el.classList.add("on"); });
  }

  function setProgress(pct, label) {
    if (state.finished) return;
    const next = Math.max(state.progress || 0, Math.max(0, Math.min(100, Number(pct) || 0)));
    state.progress = next;
    ["dlBox", "sheetBox"].forEach((id) => { const el = $(id); if (el) el.classList.add("on"); });
    ["dlFill", "sheetFill"].forEach((id) => { const el = $(id); if (el) el.style.width = next + "%"; });
    const text = label || (Math.round(next) + "%");
    ["dlPct", "sheetPct"].forEach((id) => { const el = $(id); if (el) el.textContent = text; });
  }

  function isApple() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent || "")
      || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  }

  function nativeSave(url, filename) {
    const a = document.createElement("a");
    a.href = url;
    a.setAttribute("download", filename || "amethora.zip");
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => a.remove(), 4000);
  }

  function pullFile(url, onPct) {
    return new Promise(function (resolve, reject) {
      const xhr = new XMLHttpRequest();
      xhr.open("GET", url);
      xhr.responseType = "blob";
      xhr.onprogress = function (e) {
        if (e.lengthComputable && e.total > 0) onPct(100 * e.loaded / e.total);
      };
      xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.response);
        else reject(new Error("http"));
      };
      xhr.onerror = function () { reject(new Error("net")); };
      xhr.send();
    });
  }

  async function saveRemote(url, filename) {
    if (state.saving) return;
    state.saving = true;
    const continuing = (state.progress || 0) >= 99;
    if (!continuing) {
      state.finished = false;
      state.progress = 0;
      ["dlDone", "sheetDone"].forEach((i) => { const el = $(i); if (el) el.classList.remove("on"); });
      setProgress(0);
    }
    try {
      if (isApple() && String(filename).toLowerCase().endsWith(".zip")) {
        nativeSave(url, filename);
        setProgress(100, "100%");
        showDone();
        return;
      }
      const blob = await pullFile(url, function (pct) {
        if (!continuing) setProgress(pct);
      });
      setProgress(100);
      const type = String(filename).toLowerCase().endsWith(".zip")
        ? "application/zip"
        : "video/mp4";
      const file = new File([blob], filename, { type: type });
      let handed = false;
      try {
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
          handed = true;
        }
      } catch (e) {
        if (e && e.name === "AbortError") handed = true;
      }
      if (!handed) {
        const href = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = href;
        a.download = filename;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        setTimeout(function () { URL.revokeObjectURL(href); a.remove(); }, 20000);
      }
      showDone();
    } catch (err) {
      state.saving = false;
      if ($("dlPct")) $("dlPct").textContent = "erro";
      if ($("sheetPct")) $("sheetPct").textContent = "erro";
    }
  }

  async function openPreview(value) {
    resetPreview();
    go.disabled = true;
    go.textContent = "…";
    $("sheetKicker").textContent = "Amethora";
    $("sheetTitle").textContent = "Perfil";
    $("sheetSub").textContent = "";
    skeletonProfile();
    try {
      const res = await fetch("/api/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: value }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(fmtDetail(data) || "Amethora");
      state.previewId = data.id;
      state.kind = (data.profile && data.profile.kind) || "profile";
      applyProfile(data.profile || {});
      (data.videos || []).forEach(addVideo);
      enterMode();
      if (state.kind !== "video") listenPreview(data.id);
      refreshSheet();
    } catch (err) {
      $("sheetTitle").textContent = "Amethora";
      $("sheetSub").textContent = err.message;
    } finally {
      go.disabled = false;
      go.textContent = "Abrir";
    }
  }

  function skeletonProfile() {
    ["nick", "handle", "bio", "stFollowing", "stFollowers", "stLikes", "stPosts"].forEach((id) => {
      $(id).classList.add("sk");
    });
  }

  function applyProfile(p) {
    state.profile = p;
    ["nick", "handle", "bio", "stFollowing", "stFollowers", "stLikes", "stPosts"].forEach((id) => {
      $(id).classList.remove("sk");
    });
    $("nick").textContent = p.nickname || p.handle || "Amethora";
    $("handle").textContent = p.handle || "";
    $("bio").textContent = p.bio || "";
    $("stFollowing").textContent = compact(p.following);
    $("stFollowers").textContent = compact(p.followers);
    $("stLikes").textContent = compact(p.likes);
    $("stPosts").textContent = p.videos || 0;
    const wrap = document.querySelector(".avatar-wrap");
    const fb = $("avatarFb");
    fb.textContent = (p.nickname || p.handle || "A").replace("@", "").charAt(0).toUpperCase();
    wrap.classList.remove("has-img");
    if (p.avatar) {
      $("avatar").onload = () => wrap.classList.add("has-img");
      $("avatar").onerror = () => wrap.classList.remove("has-img");
      $("avatar").src = imgUrl(p.avatar);
    }
    $("listState").textContent = "grid";
  }

  function listenPreview(id) {
    if (state.source) state.source.close();
    state.source = new EventSource(`/api/preview/${id}/stream`);
    state.source.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "hello" && msg.preview) {
        applyProfile(msg.preview.profile || {});
        (msg.preview.videos || []).forEach(addVideo);
        if (msg.preview.list_done) markReady(msg.preview.count);
      }
      if (msg.type === "video" && msg.video) addVideo(msg.video);
      if (msg.type === "status" && msg.status === "ready") markReady(msg.count);
      if (msg.type === "status" && msg.status === "error") {
        $("listState").textContent = msg.message || "—";
      }
    };
  }

  function addVideo(v) {
    if (!v || !v.id || state.videos.some((x) => x.id === v.id)) return;
    state.videos.push(v);
    $("stPosts").textContent = state.profile?.videos || state.videos.length;
    $("listState").textContent = `${state.videos.length}` + (state.profile?.videos ? ` de ${state.profile.videos}` : "");
    const i = state.videos.length;
    const cell = document.createElement("article");
    cell.className = "cell";
    cell.dataset.id = v.id;
    cell.style.animationDelay = `${Math.min(i, 24) * 18}ms`;
    const src = v.thumb ? imgUrl(v.thumb) : "";
    const mark = v.kind === "photo" ? "▣" : "▶";
    cell.innerHTML = `
      ${src ? `<img alt="" loading="lazy" src="${src}" />` : ""}
      <span class="check"></span>
      <span class="play">${mark}</span>
      <span class="meta">${mark} ${compact(v.views || 0)}</span>`;
    cell.addEventListener("click", () => onCell(v, cell));
    grid.appendChild(cell);
    refreshSheet();
  }

  function onCell(v, cell) {
    if (state.selecting) {
      if (state.selected.has(v.id)) state.selected.delete(v.id);
      else state.selected.add(v.id);
      cell.classList.toggle("on", state.selected.has(v.id));
      refreshSheet();
      return;
    }
    if (v.kind === "photo") return;
    openPlayer(state.videos.findIndex((x) => x.id === v.id));
  }

  function paintSelection() {
    grid.querySelectorAll(".cell").forEach((c) => {
      c.classList.toggle("on", state.selected.has(c.dataset.id));
    });
    $("selectAll").textContent = state.selected.size === state.videos.length ? "Limpar" : "Marcar visíveis";
  }

  function markReady(count) {
    state.listDone = true;
    $("listState").textContent = `${count || state.videos.length}`;
    refreshSheet();
  }

  function enterMode() {
    const one = state.kind === "video";
    document.body.classList.toggle("mode-single", one);
    $("stage").hidden = one;
    $("single").hidden = !one;
    $("sheet").hidden = one;
    $("packSeg").hidden = one;
    $("dlAll").hidden = one;
    $("selectToggle").hidden = one;
    if (one && state.videos[0]) {
      const v = state.videos[0];
      if (v.thumb) $("singleThumb").src = imgUrl(v.thumb);
      $("singleCap").textContent = [v.nickname || v.uploader, v.title].filter(Boolean).join(" · ");
    } else if (!one) {
      $("sheet").hidden = false;
    }
  }

  function refreshSheet() {
    const n = state.videos.length;
    const sel = state.selected.size;
    const one = state.kind === "video";
    $("selCount").textContent = !one && sel ? `${sel}` : "";
    $("dlSel").hidden = one || !(state.selecting && sel);
    $("dlSel").textContent = `Selecionados (${sel})`;
    $("dlAll").hidden = one;
    $("dlOne").hidden = !one;
    $("packSeg").hidden = one;
    $("dlAll").textContent = `Tudo (${n}${!state.listDone && n ? "…" : ""})`;
    if (!state.jobId) $("dlAll").disabled = n === 0;
    $("dlOne").disabled = n === 0;
    if (!state.jobId) {
      $("sheetKicker").textContent = "Amethora";
      $("sheetTitle").textContent = one ? "" : (state.profile?.nickname || "Perfil");
      $("sheetSub").textContent = one ? "" : `${n}`;
    }
  }

  async function startJob(mode) {
    if (!state.previewId) return;
    if (mode === "selected" && state.selected.size === 0) return;
    if (state.saving && !state.finished) return;
    if (state.jobId && !state.finished) {
      listenJob(state.jobId);
      return;
    }
    if (state.finished) {
      state.jobId = null;
      state.saving = false;
      state.finished = false;
      state.progress = 0;
    }
    $("dlAll").disabled = true;
    $("dlSel").disabled = true;
    $("dlOne").disabled = true;
    state.finished = false;
    state.progress = 0;
    ["dlDone", "sheetDone"].forEach((i) => { const el = $(i); if (el) el.classList.remove("on"); });
    $("meterTxt").textContent = "";
    $("cancelDl").hidden = false;
    $("dlFile").hidden = true;
    $("fileList").hidden = true;
    $("fileList").innerHTML = "";
    try {
      const res = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          preview_id: state.previewId,
          mode,
          pack: state.kind === "video" ? "loose" : state.pack,
          ids: mode === "selected" ? [...state.selected] : [],
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(fmtDetail(data) || "Amethora");
      state.jobId = data.id;
      listenJob(data.id);
    } catch (err) {
      $("meterTxt").textContent = err.message;
      $("dlAll").disabled = false;
      $("dlSel").disabled = false;
      $("dlOne").disabled = false;
      $("cancelDl").hidden = true;
    }
  }

  function jobProgress(job) {
    const done = (job.done_ids && job.done_ids.length) || (job.files && job.files.length) || job.item || 0;
    const total = job.total || 0;
    const pct = total ? (100 * done / total) : (Number(job.percent) || 0);
    const label = total ? `${done} / ${total}` : (job.message || "");
    setProgress(pct, label);
    if (job.message) {
      $("sheetTitle").textContent = job.status === "waiting" ? "Lista" : "Baixando";
      $("sheetSub").textContent = job.message;
    }
  }

  function listenJob(id) {
    if (state.jobSource) { state.jobSource.close(); state.jobSource = null; }
    const es = new EventSource(`/api/jobs/${id}/stream`);
    state.jobSource = es;
    es.onerror = function () {
      if (state.finished || state.saving) es.close();
    };
    es.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "hello" && msg.job && msg.job.status) {
        jobProgress(msg.job);
        if (msg.job.status === "done") {
          finishJob(id, {
            files: (msg.job.files || []).length,
            file_list: msg.job.files || [],
            artifact_name: msg.job.artifact_name,
            artifact_size: msg.job.artifact_size,
            size_h: msg.job.size_h,
            zip: msg.job.pack === "zip",
            pack: msg.job.pack,
          });
        } else if (msg.job.status === "error" || msg.job.status === "cancelled") {
          $("sheetTitle").textContent = "Amethora";
          $("sheetSub").textContent = msg.job.message || msg.job.error || "";
          $("meterTxt").textContent = msg.job.message || "";
          $("dlAll").disabled = false;
          $("dlSel").disabled = false;
          $("dlOne").disabled = false;
          $("cancelDl").hidden = true;
          if (msg.job.status === "cancelled") state.jobId = null;
        }
      }
      if (msg.type === "status" && (msg.status === "running" || msg.status === "waiting" || msg.status === "zipping")) {
        const done = msg.item || 0;
        const total = msg.total || 0;
        if (total) setProgress(100 * done / total, `${done} / ${total}`);
        else if (msg.message) setProgress(state.progress || 1, msg.message);
        $("sheetTitle").textContent = msg.status === "zipping" ? "ZIP" : "Baixando";
        $("sheetSub").textContent = msg.message || "";
      }
      if (msg.type === "file") {
        const done = msg.item || 0;
        const total = msg.total || 0;
        if (total) setProgress(100 * done / total, `${done} / ${total}`);
      }
      if (msg.type === "done") finishJob(id, msg);
      if (msg.type === "status" && (msg.status === "error" || msg.status === "cancelled")) {
        $("sheetTitle").textContent = "Amethora";
        $("sheetSub").textContent = msg.message || "";
        $("meterTxt").textContent = msg.message || "";
        $("dlAll").disabled = false;
        $("dlSel").disabled = false;
        $("dlOne").disabled = false;
        $("cancelDl").hidden = true;
        if (msg.status === "cancelled") state.jobId = null;
      }
    };
  }

  function finishJob(id, msg) {
    if (state.finished || state.saving) return;
    if (state.jobSource) { state.jobSource.close(); state.jobSource = null; }
    $("sheetKicker").textContent = "Amethora";
    $("sheetTitle").textContent = "Pronto";
    $("sheetSub").textContent = `${msg.files || 0} · ${msg.size_h || ""}`;
    $("cancelDl").hidden = true;
    $("dlAll").disabled = false;
    $("dlSel").disabled = false;
    $("dlOne").disabled = false;
    if (state.kind === "video" && (msg.file_list || [])[0]) {
      const f = msg.file_list[0];
      $("dlOne").hidden = true;
      const a = $("dlFileOne");
      a.hidden = true;
      a.href = `/api/jobs/${id}/file/${encodeURIComponent(f.name)}`;
      a.setAttribute("download", f.name);
      saveRemote(a.href, f.name);
    } else if (msg.zip && msg.artifact_name) {
      const href = `/api/jobs/${id}/download`;
      $("dlFile").hidden = false;
      $("dlFile").textContent = "Salvar ZIP";
      $("dlFile").href = href;
      $("dlFile").setAttribute("download", msg.artifact_name);
      setProgress(100, "100%");
      const big = Number(msg.artifact_size || 0) > 40 * 1024 * 1024;
      if (isApple() || big) {
        nativeSave(href, msg.artifact_name);
        showDone();
      } else {
        saveRemote(href, msg.artifact_name);
      }
    } else {
      const list = $("fileList");
      list.hidden = false;
      list.innerHTML = "";
      (msg.file_list || []).forEach((f) => {
        const a = document.createElement("a");
        a.href = `/api/jobs/${id}/file/${encodeURIComponent(f.name)}`;
        a.setAttribute("download", f.name);
        a.innerHTML = `<span>${escapeHtml(pretty(f.name))}</span><span>${escapeHtml(f.size_h || "")}</span>`;
        a.addEventListener("click", (ev) => {
          ev.preventDefault();
          saveRemote(a.href, f.name);
        });
        list.appendChild(a);
      });
      if ((msg.file_list || []).length) showDone();
    }
  }

  function openPlayer(index) {
    if (index < 0 || index >= state.videos.length || !state.previewId) return;
    const v = state.videos[index];
    if (v && v.kind === "photo") return;
    state.playIndex = index;
    document.body.classList.add("player-on");
    player.hidden = false;
    $("playerTitle").textContent = pretty(v.title || "");
    vidEl.setAttribute("playsinline", "");
    vidEl.setAttribute("webkit-playsinline", "");
    vidEl.src = `/api/play/${state.previewId}/${encodeURIComponent(v.id)}`;
    const play = vidEl.play();
    if (play && play.catch) play.catch(() => {});
    $("playerPrev").hidden = index <= 0;
    $("playerNext").hidden = index >= state.videos.length - 1;
  }

  function closePlayer() {
    vidEl.pause();
    vidEl.removeAttribute("src");
    vidEl.load();
    player.hidden = true;
    document.body.classList.remove("player-on");
  }

  function stepPlay(dir) {
    openPlayer(state.playIndex + dir);
  }

  function togglePlay() {
    if (vidEl.paused) vidEl.play();
    else vidEl.pause();
  }

  function syncBar() {
    const d = vidEl.duration || 0;
    const c = vidEl.currentTime || 0;
    $("playerFill").style.width = d ? `${(c / d) * 100}%` : "0";
    $("playerTime").textContent = fmtTime(c);
  }

  function resetPreview() {
    closePlayer();
    if (state.source) state.source.close();
    if (state.jobSource) state.jobSource.close();
    state.previewId = null;
    state.kind = "profile";
    document.body.classList.remove("mode-single", "player-on");
    $("single").hidden = true;
    $("stage").hidden = true;
    $("dlFileOne").hidden = true;
    $("dlOne").hidden = false;
    state.videos = [];
    state.selected.clear();
    state.selecting = false;
    state.listDone = false;
    state.jobId = null;
    state.finished = false;
    state.saving = false;
    state.progress = 0;
    ["dlBox", "sheetBox"].forEach((i) => { const el = $(i); if (el) el.classList.remove("on"); });
    ["dlDone", "sheetDone"].forEach((i) => { const el = $(i); if (el) el.classList.remove("on"); });
    grid.innerHTML = "";
    grid.classList.remove("selecting");
    $("selectToggle").classList.remove("on");
    $("dlFile").hidden = true;
    $("fileList").hidden = true;
    $("fileList").innerHTML = "";
    $("meter").hidden = true;
    $("cancelDl").hidden = true;
    $("meterBar").style.width = "0";
    $("meterTxt").textContent = "";
  }

  function pretty(name) {
    return String(name).replace(/^[A-Za-z0-9._]+_/, "").replace(/_/g, " ");
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function fmtDetail(data) {
    if (!data) return "";
    if (typeof data.detail === "string") return data.detail;
    if (Array.isArray(data.detail)) return data.detail.map((d) => d.msg || d).join(" ");
    return "";
  }

  if (navigator.serviceWorker) {
    navigator.serviceWorker.getRegistrations().then(function (rs) {
      rs.forEach(function (r) { r.unregister(); });
    });
  }

  const cfg = window.AMETHORA || {};
  if (cfg.adsenseClient && cfg.adsenseSlots) {
    const s = document.createElement("script");
    s.async = true;
    s.crossOrigin = "anonymous";
    s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${cfg.adsenseClient}`;
    document.head.appendChild(s);
  }
})();
