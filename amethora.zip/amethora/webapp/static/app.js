(() => {
  const $ = (id) => document.getElementById(id);
  const q = $("q");
  const form = $("search");
  const stage = $("stage");
  const grid = $("grid");
  const sheet = $("sheet");
  const go = $("go");
  const player = $("player");
  const vidEl = $("playerVid");

  const state = {
    previewId: null,
    videos: [],
    selected: new Set(),
    selecting: false,
    listDone: false,
    profile: null,
    source: null,
    jobId: null,
    jobSource: null,
    pack: "zip",
    playIndex: 0,
  };

  document.querySelectorAll(".seg-btn[data-theme]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.documentElement.dataset.theme = btn.dataset.theme;
      document.querySelectorAll(".seg-btn[data-theme]").forEach((b) => b.classList.toggle("on", b === btn));
      localStorage.setItem("amethora-theme", btn.dataset.theme);
    });
  });
  const savedTheme = localStorage.getItem("amethora-theme");
  if (savedTheme) {
    document.documentElement.dataset.theme = savedTheme;
    document.querySelectorAll(".seg-btn[data-theme]").forEach((b) => b.classList.toggle("on", b.dataset.theme === savedTheme));
  }

  document.querySelectorAll("#packSeg .seg-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.pack = btn.dataset.pack;
      document.querySelectorAll("#packSeg .seg-btn").forEach((b) => b.classList.toggle("on", b === btn));
    });
  });

  $("paste").addEventListener("click", async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (t) q.value = t.trim().replace(/^@/, "");
    } catch {
      q.focus();
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const value = q.value.trim();
    if (!value) return;
    await openPreview(value);
  });

  $("selectToggle").addEventListener("click", () => {
    state.selecting = !state.selecting;
    grid.classList.toggle("selecting", state.selecting);
    $("selectToggle").classList.toggle("on", state.selecting);
    $("selectToggle").textContent = state.selecting ? "Pronto" : "Selecionar";
    $("selectAll").hidden = !state.selecting;
    refreshSheet();
  });

  $("selectAll").addEventListener("click", () => {
    if (state.selected.size === state.videos.length) state.selected.clear();
    else state.videos.forEach((v) => state.selected.add(v.id));
    paintSelection();
    refreshSheet();
  });

  $("dlAll").addEventListener("click", () => startJob("all"));
  $("dlSel").addEventListener("click", () => startJob("selected"));
  $("cancelDl").addEventListener("click", async () => {
    if (!state.jobId) return;
    await fetch(`/api/jobs/${state.jobId}/cancel`, { method: "POST" });
  });

  $("playerClose").addEventListener("click", closePlayer);
  $("playerPlay").addEventListener("click", togglePlay);
  $("playerMute").addEventListener("click", () => {
    vidEl.muted = !vidEl.muted;
    $("playerMute").textContent = vidEl.muted ? "×" : "♪";
  });
  $("playerPrev").addEventListener("click", () => stepPlay(-1));
  $("playerNext").addEventListener("click", () => stepPlay(1));
  $("playerBar").addEventListener("click", (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const p = (e.clientX - r.left) / r.width;
    if (vidEl.duration) vidEl.currentTime = p * vidEl.duration;
  });
  vidEl.addEventListener("timeupdate", syncBar);
  vidEl.addEventListener("ended", () => { $("playerPlay").textContent = "▶"; });
  vidEl.addEventListener("play", () => { $("playerPlay").textContent = "❚❚"; });
  vidEl.addEventListener("pause", () => { $("playerPlay").textContent = "▶"; });

  function imgUrl(u) {
    if (!u) return "";
    return `/api/img?u=${encodeURIComponent(u)}`;
  }

  function compact(n) {
    n = Number(n || 0);
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(".0", "") + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(".0", "") + "M";
    if (n >= 1e4) return (n / 1e3).toFixed(1).replace(".0", "") + "K";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
    return String(n);
  }

  function fmtTime(s) {
    s = Math.max(0, Math.floor(s || 0));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }

  async function openPreview(value) {
    resetPreview();
    go.disabled = true;
    go.textContent = "…";
    stage.hidden = false;
    sheet.hidden = false;
    $("sheetKicker").textContent = "Amethora";
    $("sheetTitle").textContent = "Perfil";
    $("sheetSub").textContent = "";
    skeletonProfile();
    try {
      const res = await fetch("/api/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: value }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(fmtDetail(data) || "Amethora");
      state.previewId = data.id;
      applyProfile(data.profile || {});
      (data.videos || []).forEach(addVideo);
      listenPreview(data.id);
      refreshSheet();
    } catch (err) {
      $("sheetTitle").textContent = "Amethora";
      $("sheetSub").textContent = err.message;
    } finally {
      go.disabled = false;
      go.textContent = "Abrir";
    }
  }

  function skeletonProfile() {
    ["nick", "handle", "bio", "stFollowing", "stFollowers", "stLikes", "stPosts"].forEach((id) => {
      $(id).classList.add("sk");
    });
  }

  function applyProfile(p) {
    state.profile = p;
    ["nick", "handle", "bio", "stFollowing", "stFollowers", "stLikes", "stPosts"].forEach((id) => {
      $(id).classList.remove("sk");
    });
    $("nick").textContent = p.nickname || p.handle || "Amethora";
    $("handle").textContent = p.handle || "";
    $("bio").textContent = p.bio || "";
    $("stFollowing").textContent = compact(p.following);
    $("stFollowers").textContent = compact(p.followers);
    $("stLikes").textContent = compact(p.likes);
    $("stPosts").textContent = p.videos || 0;
    const wrap = document.querySelector(".avatar-wrap");
    const fb = $("avatarFb");
    fb.textContent = (p.nickname || p.handle || "A").replace("@", "").charAt(0).toUpperCase();
    wrap.classList.remove("has-img");
    if (p.avatar) {
      $("avatar").onload = () => wrap.classList.add("has-img");
      $("avatar").onerror = () => wrap.classList.remove("has-img");
      $("avatar").src = imgUrl(p.avatar);
    }
    $("listState").textContent = "grid";
  }

  function listenPreview(id) {
    if (state.source) state.source.close();
    state.source = new EventSource(`/api/preview/${id}/stream`);
    state.source.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "hello" && msg.preview) {
        applyProfile(msg.preview.profile || {});
        (msg.preview.videos || []).forEach(addVideo);
        if (msg.preview.list_done) markReady(msg.preview.count);
      }
      if (msg.type === "video" && msg.video) addVideo(msg.video);
      if (msg.type === "status" && msg.status === "ready") markReady(msg.count);
      if (msg.type === "status" && msg.status === "error") {
        $("listState").textContent = msg.message || "—";
      }
    };
  }

  function addVideo(v) {
    if (!v || !v.id || state.videos.some((x) => x.id === v.id)) return;
    state.videos.push(v);
    $("stPosts").textContent = state.profile?.videos || state.videos.length;
    $("listState").textContent = `${state.videos.length}` + (state.profile?.videos ? ` de ${state.profile.videos}` : "");
    const i = state.videos.length;
    const cell = document.createElement("article");
    cell.className = "cell";
    cell.dataset.id = v.id;
    cell.style.animationDelay = `${Math.min(i, 24) * 18}ms`;
    const src = v.thumb ? imgUrl(v.thumb) : "";
    cell.innerHTML = `
      ${src ? `<img alt="" loading="lazy" src="${src}" />` : ""}
      <span class="check"></span>
      <span class="play">▶</span>
      <span class="meta">▶ ${compact(v.views || 0)}</span>`;
    cell.addEventListener("click", () => onCell(v, cell));
    grid.appendChild(cell);
    refreshSheet();
  }

  function onCell(v, cell) {
    if (state.selecting) {
      if (state.selected.has(v.id)) state.selected.delete(v.id);
      else state.selected.add(v.id);
      cell.classList.toggle("on", state.selected.has(v.id));
      refreshSheet();
      return;
    }
    openPlayer(state.videos.findIndex((x) => x.id === v.id));
  }

  function paintSelection() {
    grid.querySelectorAll(".cell").forEach((c) => {
      c.classList.toggle("on", state.selected.has(c.dataset.id));
    });
    $("selectAll").textContent = state.selected.size === state.videos.length ? "Limpar" : "Marcar visíveis";
  }

  function markReady(count) {
    state.listDone = true;
    $("listState").textContent = `${count || state.videos.length}`;
    refreshSheet();
  }

  function refreshSheet() {
    const n = state.videos.length;
    const sel = state.selected.size;
    $("selCount").textContent = sel ? `${sel}` : "";
    $("dlSel").hidden = !(state.selecting && sel);
    $("dlSel").textContent = `Selecionados (${sel})`;
    $("dlAll").textContent = `Tudo (${n}${!state.listDone && n ? "…" : ""})`;
    $("dlAll").disabled = n === 0;
    if (!state.jobId) {
      $("sheetKicker").textContent = "Amethora";
      $("sheetTitle").textContent = state.profile?.nickname || "Perfil";
      $("sheetSub").textContent = state.listDone ? `${n}` : `${n}`;
    }
  }

  async function startJob(mode) {
    if (!state.previewId) return;
    if (mode === "selected" && state.selected.size === 0) return;
    $("dlAll").disabled = true;
    $("dlSel").disabled = true;
    $("meter").hidden = false;
    $("cancelDl").hidden = false;
    $("dlFile").hidden = true;
    $("fileList").hidden = true;
    $("fileList").innerHTML = "";
    try {
      const res = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          preview_id: state.previewId,
          mode,
          pack: state.pack,
          ids: mode === "selected" ? [...state.selected] : [],
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(fmtDetail(data) || "Amethora");
      state.jobId = data.id;
      listenJob(data.id);
    } catch (err) {
      $("meterTxt").textContent = err.message;
      $("dlAll").disabled = false;
      $("dlSel").disabled = false;
    }
  }

  function listenJob(id) {
    if (state.jobSource) state.jobSource.close();
    state.jobSource = new EventSource(`/api/jobs/${id}/stream`);
    state.jobSource.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "hello" && msg.job) applyJob(msg.job);
      if (msg.type === "status") applyJob(msg);
      if (msg.type === "progress") {
        const pct = Number(msg.percent || 0);
        const overall = msg.total ? ((msg.item - 1 + pct / 100) / msg.total) * 100 : pct;
        $("meterBar").style.width = `${Math.max(2, overall)}%`;
        $("meterTxt").textContent = `${msg.item || 0}/${msg.total || 0}`;
      }
      if (msg.type === "done") finishJob(id, msg);
      if (msg.type === "status" && msg.status === "error") {
        $("sheetTitle").textContent = "Amethora";
        $("sheetSub").textContent = msg.message || "";
        $("dlAll").disabled = false;
        $("dlSel").disabled = false;
        $("cancelDl").hidden = true;
      }
    };
  }

  function finishJob(id, msg) {
    $("meterBar").style.width = "100%";
    $("sheetKicker").textContent = "Amethora";
    $("sheetTitle").textContent = "Pronto";
    $("sheetSub").textContent = `${msg.files} · ${msg.size_h || ""}`;
    $("cancelDl").hidden = true;
    $("dlAll").disabled = false;
    $("dlSel").disabled = false;
    if (msg.zip && msg.artifact_name) {
      $("dlFile").hidden = false;
      $("dlFile").textContent = "ZIP";
      $("dlFile").href = `/api/jobs/${id}/download`;
      $("dlFile").setAttribute("download", msg.artifact_name);
    } else {
      const list = $("fileList");
      list.hidden = false;
      list.innerHTML = "";
      (msg.file_list || []).forEach((f) => {
        const a = document.createElement("a");
        a.href = `/api/jobs/${id}/file/${encodeURIComponent(f.name)}`;
        a.setAttribute("download", f.name);
        a.innerHTML = `<span>${escapeHtml(pretty(f.name))}</span><span>${escapeHtml(f.size_h || "")}</span>`;
        list.appendChild(a);
      });
    }
  }

  function applyJob(j) {
    if (j.message) $("meterTxt").textContent = j.message;
    if (j.total) {
      const pct = j.total ? (100 * (j.item || 0)) / j.total : 0;
      $("meterBar").style.width = `${pct}%`;
    }
  }

  function openPlayer(index) {
    if (index < 0 || index >= state.videos.length || !state.previewId) return;
    state.playIndex = index;
    const v = state.videos[index];
    player.hidden = false;
    $("playerTitle").textContent = pretty(v.title || "");
    vidEl.src = `/api/play/${state.previewId}/${encodeURIComponent(v.id)}`;
    vidEl.play().catch(() => {});
    $("playerPrev").hidden = index <= 0;
    $("playerNext").hidden = index >= state.videos.length - 1;
  }

  function closePlayer() {
    vidEl.pause();
    vidEl.removeAttribute("src");
    vidEl.load();
    player.hidden = true;
  }

  function stepPlay(dir) {
    openPlayer(state.playIndex + dir);
  }

  function togglePlay() {
    if (vidEl.paused) vidEl.play();
    else vidEl.pause();
  }

  function syncBar() {
    const d = vidEl.duration || 0;
    const c = vidEl.currentTime || 0;
    $("playerFill").style.width = d ? `${(c / d) * 100}%` : "0";
    $("playerTime").textContent = fmtTime(c);
  }

  function resetPreview() {
    closePlayer();
    if (state.source) state.source.close();
    if (state.jobSource) state.jobSource.close();
    state.previewId = null;
    state.videos = [];
    state.selected.clear();
    state.selecting = false;
    state.listDone = false;
    state.jobId = null;
    grid.innerHTML = "";
    grid.classList.remove("selecting");
    $("selectToggle").classList.remove("on");
    $("dlFile").hidden = true;
    $("fileList").hidden = true;
    $("fileList").innerHTML = "";
    $("meter").hidden = true;
    $("cancelDl").hidden = true;
    $("meterBar").style.width = "0";
    $("meterTxt").textContent = "";
  }

  function pretty(name) {
    return String(name).replace(/^[A-Za-z0-9._]+_/, "").replace(/_/g, " ");
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function fmtDetail(data) {
    if (!data) return "";
    if (typeof data.detail === "string") return data.detail;
    if (Array.isArray(data.detail)) return data.detail.map((d) => d.msg || d).join(" ");
    return "";
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  }

  const cfg = window.AMETHORA || {};
  if (cfg.adsenseClient && cfg.adsenseSlots) {
    const s = document.createElement("script");
    s.async = true;
    s.crossOrigin = "anonymous";
    s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${cfg.adsenseClient}`;
    document.head.appendChild(s);
  }
})();
