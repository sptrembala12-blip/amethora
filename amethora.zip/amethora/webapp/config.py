"""Configuração pública do Amethora. Preencha o pub-id para o ar."""

ADSENSE_CLIENT = ""  # ca-pub-XXXXXXXXXXXXXXXX
ADSENSE_SLOTS = {
    "top": "",
    "feed": "",
    "footer": "",
}
SITE_NAME = "Amethora"
SITE_TAGLINE = "O perfil, inteiro."
