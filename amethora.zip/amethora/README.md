# Amethora

Preview de perfil do TikTok (foto, seguidores, curtidas, grid) e download em ZIP — tudo ou só os marcados.

Tema lilás / branco, visual iOS. Pronto para GitHub + Render.

## Subir no Render

1. Crie um repo no GitHub e envie esta pasta.
2. Em [Render](https://render.com) → **New → Web Service** → conecte o repo.
3. Runtime: **Docker** (usa o `Dockerfile` — instala `ffmpeg` + `yt-dlp`).
4. Deploy.

Ou, se preferir o `render.yaml`:

```bash
# no dashboard, New → Blueprint → este repositório
```

O serviço escuta em `0.0.0.0:$PORT` (Render injeta a porta).

Health check: `/api/health`

## Rodar local

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# precisa de ffmpeg no sistema
uvicorn webapp.app:app --host 0.0.0.0 --port 8080
```

## AdSense

1. `webapp/static/config.js` — cole `adsenseClient` (`ca-pub-…`) e os slots.
2. `webapp/static/ads.txt` — descomente a linha e troque o `pub-…`.
3. Páginas `/privacy` e `/terms` já existem.

O Google costuma recusar site que só baixa conteúdo de terceiro. Use para arquivo pessoal e deixe os termos claros.

## CLI (opcional)

```bash
python tiktok_bulk_downloader.py "https://www.tiktok.com/@usuario"
```
